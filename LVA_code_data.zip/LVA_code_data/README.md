# Transferable Lindblad Variational Ansatz

Code and data accompanying **Transferable Lindblad Variational Ansatz for Accelerated Steady-State Preparation**, Yun-Zhuo Fan and Dan-Bo Zhang, manuscript revision 2 November 2026.

This repository contains only the numerical results displayed in **main Figures 2–6 and Supplemental Tables S1–S8**, their required inputs, and the computation/plotting code. **Figure 1 is a schematic and is excluded**, including its artwork and plotting script. The manuscript and its LaTeX dependencies are not duplicated here.

## Quick start

Use Python 3.11 or newer and an isolated environment:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run.py verify
python run.py figures
python run.py response-table
```

`verify` checks file hashes, the source-training evaluation counts, all 105 Figure 6 coordinates, the 30 attained matched-accuracy gains against the sampled candidates, 16 residual/Jacobian matrices, and the finite-size bulk identities. It does not launch training.

`figures` redraws only Figures 2–6 using saved values. The output names follow the manuscript: `fig2`, `fig3`, `fig_preimage` (Figure 4), `fig_transfer` (Figure 5), and `fig5` (Figure 6). Each is written under `reproduced/figures/` in PDF, SVG, and PNG formats. No LaTeX installation is required. `response-table` reconstructs Table S7's response columns from the saved matrices; its final nonlinear-step columns come from the saved correction records.

All new calculations and caches are written under `reproduced/`, which is ignored by Git. The archived `data/` files are inputs and should remain unchanged.

## Contents and numerical recomputation

| Path | Contents |
|---|---|
| `data/Figure2/` | Source training, parameters, candidate summaries and plotted baseline coordinates |
| `data/Figure3/` | Selected protocols, modal spectra, trajectories and coordinates |
| `data/Figure4/` | Dissipative-preimage and matched-input diagnostic curves |
| `data/Figure5/` | Direct/sequential transfer points and all 28 displayed endpoint records |
| `data/Figure6/` | Plotted coordinates, gains, supporting candidate values, time scans and selected parameters |
| `data/Response/` | Response matrices, feasible correction records, and bulk-identity checks |
| `data/Tables/` | Literal table values plus full-precision supporting records |
| `data/source_inputs/` | Five-spin reference states and initialization inputs needed for Figure 2 |
| `code/physics/` | Exact CPU/GPU channels, objectives, gradients, and tangent propagation |
| `code/source/` | Source-infidelity training, residual pretraining, and depth continuation |
| `code/plots/` | Plotting scripts for Figures 2–6 |
| `RESULTS_MAP.md` | Figure/table-to-data/code mapping and file-format guide |
| `REPRODUCING.md` | Commands, model conventions and computational limits |
| `PROVENANCE.json` | Original source locations and hashes before public-package cleanup |
| `FILES.csv` | File inventory, sizes and SHA-256 hashes; excludes itself |

Small-system checks and recomputations:

```bash
python run.py calculate response-check
python run.py preimage
python run.py modal
python run.py response --model tfim --sizes 5
```

Source training and target refinement can be expensive:

```bash
python run.py source --model tfim --iterations 1000
python run.py source --model xxx --iterations 1000
python run.py residual-seed --model tfim --pmax 20 --maxiter 100
python run.py calculate refine --model tfim --route 5,6 --P 7 --with-reference
python run.py baselines --model tfim --N 5 --m 9 --order 2 --tmax 40
```

`xxx` names the boundary-driven Heisenberg chain in the code; `tfim` names the bulk-dissipative Ising chain. Recomputing systems of size 10–12 with these entry points requires a compatible NVIDIA GPU/CUDA installation and the optional `requirements-gpu.txt` dependencies. Saved plots and table checks run on a CPU. See `REPRODUCING.md` before starting large jobs.

The archived records are the numerical results used by the manuscript. Reoptimization on another numerical stack can end at different finite-budget endpoints. The publication archive preserves the accepted final parameters and results; it does not claim bitwise-identical optimization across environments.

## Scope of the supporting data

The 539 scalar candidate rows and the digital time scans under Figure 6 support the sampled-minimum comparison in Figure 6(c,d) and Table S5. They are necessary to recompute the reported crossings, even when individual candidates are not drawn in Figure 6(a,b). Nonwinning optimization histories and nonselected parameters are excluded. Source candidate summaries are retained because they determine the Figure 2 random-start envelope and Table S2's total effort. The five-spin residual and Strang inputs are retained because they initialize the displayed source training.

Old experiments, alternate manuscripts, Figure 1 assets, remote-job launchers, process logs, bytecode, virtual environments, large reference-state caches, and revision reports are excluded. Historical local file paths in numerical records were removed or converted to portable archival identifiers; numerical values and arrays were preserved. `PROVENANCE.json` records original hashes; `FILES.csv` records the cleaned public files.

## Citation

Please cite the accompanying manuscript when using these data or code. Machine-readable information is in `CITATION.cff`; this snapshot has no assigned repository DOI or public repository URL.

## 中文说明

本包仅覆盖正文图2—6、补充表S1—S8及其必要输入和计算内核，不包含示意图1。优先运行 `python run.py verify` 校验文件和展示数值，再用 `python run.py figures` 重绘五幅数值图。逐图逐表对应关系见 `RESULTS_MAP.md`，重算方法和计算限制见 `REPRODUCING.md`。大尺寸训练不会由验证或重绘命令自动启动。
