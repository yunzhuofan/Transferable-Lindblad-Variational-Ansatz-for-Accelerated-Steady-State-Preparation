"""Portable entry points for displayed numerical results only."""
from pathlib import Path
import argparse,os,subprocess,sys
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLBACKEND','Agg')
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'reproduced/cache/matplotlib'))
os.environ.setdefault('NUMBA_CACHE_DIR',str(ROOT/'reproduced/cache/numba'))
os.environ.setdefault('PYTHONUTF8','1')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(key,'1')
def run(rel,extra):subprocess.run([sys.executable,str(ROOT/rel)]+extra,cwd=ROOT,check=True)
def main():
    p=argparse.ArgumentParser(description=__doc__,add_help=False)
    p.add_argument('action',choices=['verify','figures','source','source-gradient-check','residual-seed','extend','calculate','baselines','modal','preimage','response-table','response'])
    if len(sys.argv)==1 or sys.argv[1] in ['-h','--help']:
        p.print_help();return
    a,extra=p.parse_known_args()
    scripts={'verify':'code/verify.py','source':'code/source/train.py','source-gradient-check':'code/source/fidelity_objective.py','residual-seed':'code/source/residual_seed.py','extend':'code/source/extend.py','calculate':'code/calculate.py','baselines':'code/baselines.py','modal':'code/modal_calculation.py','preimage':'code/preimage_calculation.py','response-table':'code/response_table.py','response':'code/recompute_response.py'}
    if a.action=='figures':
        for n in range(2,7):run(f'code/plots/plot_F{n}.py',[])
    else:run(scripts[a.action],extra)
if __name__=='__main__':main()
