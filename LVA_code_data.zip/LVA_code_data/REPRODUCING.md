# Reproduction guide

## Models and objectives

The source size is N=5. `tfim` uses an open Ising chain with coherent generators sum(X) and sum(ZZ), and local downward jumps on every site. `xxx` uses an open Heisenberg chain with coherent generators sum(XX+YY) and sum(ZZ), with left pump/loss rates (1,0.2) and right rates (0.2,1). Z|0>=|0>, Z|1>=-|1>, sigma-minus=|1><0|; the initial state is |1><1| tensor N.

Source training minimizes `1 - squared Uhlmann fidelity`. Target post-training minimizes the local Lindblad residual, with region length 2 for TFIM and 4 for Heisenberg. All source choices use source quantities. Fidelity at a target size is an assessment quantity, not the target-training loss or an intermediate-iterate selection rule.

L-BFGS-B uses bounds `a,b in [-pi,pi]`, `tau in [0,4]`, `gtol=1e-10`, `ftol=1e-14`, `maxls=30`. The displayed infidelity source runs and target refinements have a 1000-iteration cap per call. Residual pretraining uses a separate 100-iteration cap, accounted for in Table S2. One block count means a whole grouped generator exponential, not an elementary gate count.

## Fast reproduction from archived values

```bash
python run.py verify
python run.py figures
python run.py response-table
```

No GPU, quantum hardware or fresh optimization is required. Figure 6's 30 reached gains are recomputed from the complete scalar candidate grids and baseline results. Two source-stage placeholders without target refinement are retained in the 32-row gain file. The table-response script uses the saved r/J arrays and independently recomputes Gram eigenvalues and correctable fractions; it reads the saved nonlinear correction endpoint fields.

## Independent small-system calculations

```bash
# Central finite differences of every response coordinate, compared with
# analytic tangents and adjoint gradients at N=3 for both models.
python run.py calculate response-check
python run.py source-gradient-check

# Figure 4: fresh stationary solve, exact channels, projectors and scans.
python run.py preimage

# Figure 3 / Table S6: fresh reduced Liouvillian eigensolves and trajectories.
python run.py modal

# Table S7: fresh r/J and the six-direction / full-direction constrained steps.
python run.py response --model tfim --sizes 5
python run.py response --model xxx --sizes 5
```

The response code selects the leading source eigenspaces (k=3,6,10); one-step optimization uses k=6 or all free directions, radius 0.1, physical parameter bounds and the six documented line-search lengths. A different representation/basis of exactly degenerate eigenmodes can redistribute diagnostic modal components; saved modal weights define the plotted basis.

## Training and transfer

```bash
# Recompute the Figure 2 source comparisons; can be long-running.
python run.py source --model tfim --iterations 1000
python run.py source --model xxx --iterations 1000

# Recompute the residual initializer chain separately.
python run.py residual-seed --model tfim --pmax 20 --maxiter 100
python run.py residual-seed --model xxx --pmax 50 --maxiter 100

# Additional depth continuation used for the Figure 6 resource sweeps.
python run.py extend --model xxx --P 60

# Direct / sequential / coarse-route local refinement.
python run.py calculate refine --model tfim --route 5,6 --P 7 --with-reference
python run.py calculate refine --model tfim --route 5,12 --P 7 --with-reference
python run.py calculate refine --model xxx --route 5,6,8,10,12 --P 20 --with-reference

# Independent source-size time-optimized second-order baseline.
python run.py baselines --model tfim --N 5 --m 9 --order 2 --tmax 40
```

Use the saved `initial_parameters` and final controls in the endpoint records to audit specific endpoints. The refinement entry point starts from the archived source pool and refines on the requested route with the same objective and bounds. It writes new results separately; it never replaces published records. The source trainer uses archived residual and source-baseline initializers by default. Running the residual-initializer command does not silently replace those inputs.

The generic baseline entry point scans a one-unit grid plus 0.2 spacing on [0,2], then refines competitive local minima. Use `--reverse` for the alternate second-order centering. The original paper also used selected extended scans at N=12 Heisenberg, up to time 120 with a different coarse grid and tighter threshold refinement. The complete original saved time samples are included. A fresh generic scan need not land at exactly the same finite-grid crossing; use the archived scans to reproduce the published finite-grid aggregate.

## Large systems and reference states

```bash
python -m pip install -r requirements-gpu.txt
python run.py calculate reference --model tfim --N 12
python run.py calculate reference --model xxx --N 12
python run.py response --model tfim --sizes 10 11 12
python run.py calculate bulk
```

CPU exact density matrices/number sectors are used through N=9. The supplied large-system entry points use CuPy/CUDA: a real orthonormal Pauli basis for TFIM, and all excitation-number density sectors plus exact coherent Givens factorization for Heisenberg. CUDA 12-compatible CuPy dependencies are optional; install a compatible variant for your CUDA environment.

Large reference-state caches are excluded. They can be regenerated under `reproduced/references/` using the same trace-constrained generator equations and checked for trace, positivity and stationarity. The portable large Heisenberg reference entry point starts full-sector trace-constrained GMRES from the uniform state. Historical accepted references used additional ILU/symmetry-assisted warm starts; their validation values are preserved in Table S1. Warm-start/cache differences can alter convergence cost, and regeneration at N=12 can be substantially slower. Reference generation is not part of a quick verification run.

The original Heisenberg target records include checkpoint continuation. A new uninterrupted finite-budget optimization can reach a different endpoint. Floating-point libraries, eigensolver bases and optimization trajectories can also vary. The archive supplies the selected parameters and full-precision results used for the paper; fast checks verify those exact archived results. Full-size training, large reference generation and all-GPU recomputation are not claimed to have been rerun when preparing this public package.

## Package validation

`VALIDATION.json` records the checks actually run during release preparation and the Python/numerical-library versions used for them. `FILES.csv` hashes every delivered file except itself. `PROVENANCE.json` links copied data/code to original local source identifiers and original hashes; paths there are archival identifiers, not runtime dependencies. No scripts depend on the author's machine paths.
