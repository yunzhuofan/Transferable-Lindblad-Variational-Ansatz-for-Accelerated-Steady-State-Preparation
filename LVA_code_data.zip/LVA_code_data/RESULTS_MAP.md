# Displayed results and their dependencies

Figure numbers refer to the current manuscript. Figure 1 is deliberately absent.

| Result | Archived data | Plotting or numerical code |
|---|---|---|
| Figure 2(a,b) | `data/Figure2/training_{tfim,xxx}.json`: augmented/INTERP/random source endpoints, parameters and per-candidate effort | `code/plots/plot_F2.py`; `code/source/train.py`; `code/source/fidelity_objective.py`; `code/source/residual_seed.py` |
| Figure 2(c,d) | Same augmented endpoints and `plotted_points_maxiter1000.csv`; time-search source inputs in `data/source_inputs/benchmark_*.json` | `plot_F2.py`; `code/baselines.py`; exact channel kernels |
| Figure 3 | `data/Figure3/`: selected protocols, full blockwise trajectories, modal eigenvalues/group weights, plotted coordinates | `code/plots/plot_F3.py`; `code/modal_calculation.py`; `lva_core.py` |
| Figure 4 | `data/Figure4/diagnostics.json`; same TFIM protocol and trajectory as Figure 3 | `code/plots/plot_F4.py`; `code/preimage_calculation.py` computes projectors, damping scans and the equal-infidelity natural input |
| Figure 5 | `data/Figure5/`: 28 direct/sequential records, both coordinate CSVs and `N12_comparison.json` | `code/plots/plot_F5.py`; `code/calculate.py refine`; local-cost/adjoint kernels |
| Figure 6(a,b) | `data/Figure6/plotted_points.csv`: 105 coordinates; `parameters.json`: retained selected records; `digital_baselines.json`: independent time searches | `code/plots/plot_F6.py`; `calculate.py refine`; `baselines.py`; `code/source/extend.py` |
| Figure 6(c,d) | `sampled_gains_full_data.csv`; `all_gain_points.csv`; `digital_baselines.json` | `plot_F6.py`; `code/verify.py` recomputes successful minimum sampled budgets and gains |
| Table S1 | `data/Tables/Table_S1.csv` and `reference_checks.json`: 16 independently computed references, N=5–12 | `calculate.py reference`; `lva_core.py`, `xxx_blocks.py`, `nn_core.py`, exact GPU backend |
| Table S2 | `Table_S2.csv`, `source_training_effort.json`, Figure 2 trial summaries and residual-seed records | `code/verify.py` sums every candidate's evaluations; `source/train.py`, `source/residual_seed.py` |
| Table S3 | `Table_S3.csv`, `data/Figure5/N12_comparison.json`, direct/sequential endpoint records | `calculate.py refine`; Figure 5 records contain the accepted controls and effort |
| Table S4 | `Table_S4.csv`, `S4_endpoints.csv`, `S4_parameters.json`; direct records reused from Figure 5 | `calculate.py refine` with routes `5,12`, `5,10,12`, `5,6,8,10,12` |
| Table S5 | `Table_S5.csv` plus all Figure 6 candidate values, crossings and baseline scans | `code/verify.py`; `baselines.py`; `calculate.py refine` |
| Table S6 | `Table_S6.csv` and the Figure 3 spectrum/group records | `modal_calculation.py` |
| Table S7 | `Table_S7.csv`; `data/Response/{tfim,xxx}/summary.json` and 16 NPZ residual/Jacobian matrices, source controls, step controls and line searches | `response_table.py` reconstructs response columns; `recompute_response.py` computes tangents/corrections; `response_analysis.py` |
| Table S8 | `Table_S8.csv`; `data/Response/bulk_identity_validation.json`: 13 sizes in two fixed-depth settings | `calculate.py bulk`; `code/verify.py` independently reconstructs nine predictions of C, K and J-transpose-r |

## Formats and conventions

- JSON records retain full-precision floating-point values, selected control arrays, optimization budgets and candidate/step summaries. Parameter rows are `(a, b, tau)` in chronological coherent-1, coherent-2, dissipative order.
- `Table_S*.csv` transcribes the printed table fields, including LaTeX expressions and rounded values. Full-precision numerical values live in the corresponding JSON/NPZ files; these CSVs should not be treated as machine-readable floating-point matrices without parsing the math formatting.
- The Figure 3 trajectory NPZ files contain `states`, `parameters` and `reference`. Response NPZ files contain `r`, `J` and `parameters`; tangents are unnormalized operators.
- `all_gain_points.csv` retains only scalar candidate values and a pointer to the retained parameter collection where available. A blank `record` means the nonwinning parameter history is intentionally omitted. Its scalar value remains necessary to check a sampled minimum.
- The dictionary keys in `data/Figure6/parameters.json` are historical record identifiers, not filesystem paths to be opened. Original input hashes in records are provenance of the original runs; use the current `FILES.csv` hashes to validate this cleaned repository.
- Baseline `time_samples` contains every saved time and infidelity for the corresponding tested block budget. Repeated entries at the same nominal budget are retained because the published aggregate selects the lowest recorded infidelity over the saved centering/search records.
- Figure 5 and 6 “before” means before refinement at the indicated size. On a sequential route, its parameters may already have been optimized at earlier sizes.

## Boundary of inclusion

An input needed to generate a displayed quantity is included even when the input is not itself plotted (for example, residual-pretraining initializers or a time scan used to establish a minimum). Unrelated target-transfer results formerly embedded in the source baseline files are excluded. Source residual schedules are truncated to the depths used in Figure 2. Source/training numerical fields and NPZ arrays are otherwise preserved, apart from portable provenance metadata.
