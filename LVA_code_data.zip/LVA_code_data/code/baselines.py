"""Time optimization of the exact grouped first-/second-order digital baseline."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import minimize_scalar
from calculate import ROOT,reference

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',choices=['tfim','xxx'],required=True);p.add_argument('--N',type=int,default=5)
    p.add_argument('--m',type=int,required=True);p.add_argument('--order',type=int,choices=[1,2],default=2)
    p.add_argument('--tmax',type=float,default=40);p.add_argument('--reverse',action='store_true')
    args=p.parse_args();model,_=reference(args.model,args.N);samples={}
    def objective(t):
        t=float(t)
        if t not in samples:
            state=model.trotter(t,args.m,args.order,args.reverse)
            metrics=model.metrics(state,trace_distance=False) if args.N<=9 else model.metrics(state)
            samples[t]=metrics['infidelity']
        return samples[t]
    grid=np.unique(np.r_[np.arange(0,args.tmax+.5,1.),np.linspace(0,2,11)])
    values=np.array([objective(t) for t in grid])
    minima=[i for i in range(1,len(grid)-1) if values[i]<=values[i-1] and values[i]<=values[i+1] and values[i]<=values.min()*1.2+1e-11]
    if not minima:minima=[max(1,min(len(grid)-2,int(np.argmin(values))))]
    for i in minima[:6]:minimize_scalar(objective,bounds=(float(grid[i-1]),float(grid[i+1])),method='bounded',options={'xatol':2e-4,'maxiter':40})
    best=min(samples,key=samples.get)
    record=dict(model=args.model,N=args.N,m=args.m,order=args.order,reverse=args.reverse,
                blocks=3*args.m if args.order==1 else 4*args.m+1,optimized_time=best,
                infidelity=samples[best],time_samples=sorted(samples.items()))
    out=ROOT/'reproduced';out.mkdir(exist_ok=True)
    dest=out/f'baseline_{args.model}_N{args.N}_m{args.m}_order{args.order}.json'
    dest.write_text(json.dumps(record,indent=2)+'\n');print(dest)

if __name__=='__main__':main()
