"""Recompute Table S7 tangents and feasible corrections at selected sizes."""
from pathlib import Path
import argparse,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'code'),str(ROOT/'code/physics')]
from calculate import cpu,reference
from response_core import response,residual_vector
from response_analysis import projection,feasible_update

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',choices=['tfim','xxx'],required=True)
    p.add_argument('--sizes',type=int,nargs='+',default=[5],choices=range(5,13))
    args=p.parse_args();model=args.model
    saved=json.loads((ROOT/f'data/Response/{model}/summary.json').read_text())
    par=np.asarray(saved['source_parameters']).ravel();P=len(par)//3;region=saved['r'];free=saved['free_coordinates']
    embed=np.eye(len(par))[:,free]
    source=np.load(ROOT/f'data/Response/{model}/response_{model}_P{P}_N5.npz')['J']@embed
    eig,vec=np.linalg.eigh(source.T@source);order=np.argsort(eig)[::-1];eig,vec=eig[order],embed@vec[:,order]
    out=ROOT/f'reproduced/response/{model}';out.mkdir(parents=True,exist_ok=True)
    records=[]
    for n in args.sizes:
        m,checks=reference(model,n)
        if n<=9:
            fn=response;residual_fn=residual_vector
        else:
            from gpu_response import Adapter,response as gpu_response,residual as gpu_residual
            adapted=object.__new__(Adapter);adapted.name=model;adapted.n=n;adapted.backend=m;adapted.index_cache={}
            m=adapted;fn=gpu_response;residual_fn=gpu_residual
        r,J,_=fn(m,par,region)
        np.savez_compressed(out/f'response_{model}_P{P}_N{n}.npz',r=r,J=J,parameters=par)
        row={'N':n,'local_cost':float(r@r),'reference_checks':checks,'direction_results':[]}
        for k in [3,6,10]:
            V=vec[:,:k];A=J@V;q=np.diag(1/np.sqrt(eig[:k]))
            d={'k':k,'source_subspace_correctable_fraction':projection(A,r)[0],
               'relative_gram_eigenvalue_min':float(np.linalg.eigvalsh(q@(A.T@A)@q)[0])}
            if k==6:d['one_step']=feasible_update(m,par,r,J,V,region,residual_fn)
            row['direction_results'].append(d)
        row['full_correctable_fraction']=projection(J@embed,r)[0]
        row['full_one_step']=feasible_update(m,par,r,J,embed,region,residual_fn)
        records.append(row)
        (out/'summary.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
        print(model,n,'response and constrained corrections complete',flush=True)
if __name__=='__main__':main()
