"""Validate inventory, figure coordinates, table summaries and saved response data."""
from pathlib import Path
import ast,csv,hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def read(rel):return json.loads((ROOT/rel).read_text(encoding='utf-8-sig'))
def csvread(rel):return list(csv.DictReader((ROOT/rel).open(encoding='utf-8-sig',newline='')))
def main():
    index=csvread('FILES.csv')
    for row in index:
        p=ROOT/row['path']
        assert p.is_file() and p.stat().st_size==int(row['bytes']),row['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
    for p in (ROOT/'code').rglob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
    assert not (ROOT/'data/Figure1').exists() and not (ROOT/'code/plots/plot_F1.py').exists()
    effort=read('data/Tables/source_training_effort.json')
    training={m:read(f'data/Figure2/training_{m}.json') for m in ['tfim','xxx']}
    for saved in effort:
        m=saved['model'];t=training[m]
        for stage in ['augmented','plain','random']:
            assert sum(trial['nfev'] for row in t[stage] for trial in row['trials'])==saved['evaluations'][stage]
        seeds=read(f'data/source_inputs/source_{m}_N5_seed0.json')['records']
        assert sum(row['evaluations'] for row in seeds)==saved['residual_seed_evaluations']
        assert sum(len(row['trials']) for row in t['augmented'])==saved['candidate_count']
    points=csvread('data/Figure6/all_gain_points.csv')
    gains=csvread('data/Figure6/sampled_gains_full_data.csv')
    baselines=read('data/Figure6/digital_baselines.json');matched=0
    for row in gains:
        if not row['gain']:continue
        candidates=[p for p in points if all(p[k]==row[k] for k in ['model','N','stage']) and float(p['infidelity'])<=float(row['threshold'])]
        assert min(int(p['B']) for p in candidates)==int(row['LVA_blocks'])
        baseline=[int(b['blocks']) for b in baselines[row['model']+'_'+row['N']] if b['order']==2 and b['infidelity']<=float(row['threshold'])]
        assert min(baseline)==int(row['second_order_blocks'])
        assert abs(float(row['second_order_blocks'])/float(row['LVA_blocks'])-float(row['gain']))<1e-12
        matched+=1
    plotted=csvread('data/Figure6/plotted_points.csv')
    for row in plotted:
        if row['stage'] in ['before','refined']:
            found=[p for p in points if all(p[k]==row[k] for k in ['model','N','stage','B'])]
            assert any(abs(float(p['infidelity'])-float(row['infidelity']))<1e-12 for p in found)
        else:
            found=[p for p in baselines[row['model']+'_'+row['N']] if p['order']==int(row['stage'][-1]) and p['blocks']==int(row['B'])]
            assert found and abs(min(p['infidelity'] for p in found)-float(row['infidelity']))<1e-12
    endpoints=csvread('data/Tables/S4_endpoints.csv')
    assert len(endpoints)==6
    response_count=0
    for model,p in [('tfim',7),('xxx',20)]:
        d=read(f'data/Response/{model}/summary.json')
        assert [r['N'] for r in d['rows']]==list(range(5,13))
        for row in d['rows']:
            z=np.load(ROOT/f'data/Response/{model}/response_{model}_P{p}_N{row["N"]}.npz')
            assert abs(float(z['r']@z['r'])-row['local_cost'])<1e-10
            assert np.isfinite(z['J']).all();response_count+=1
    independent=0
    for result in read('data/Response/bulk_identity_validation.json')['results']:
        values=result['values'];x=1/(np.array(result['sizes'])-result['r']+1)
        for i in range(2,len(values)):
            for key in ['C','K','b']:
                a=np.asarray(values[0][key]);b=np.asarray(values[1][key]);actual=np.asarray(values[i][key])
                assert np.max(np.abs(a+(x[i]-x[0])/(x[1]-x[0])*(b-a)-actual))<5e-12
            independent+=1
    print(json.dumps(dict(files_verified=len(index),figures=[2,3,4,5,6],supplemental_tables=8,figure6_coordinates=len(plotted),matched_accuracy_rows=matched,source_effort_models=2,response_matrices=response_count,independent_bulk_predictions=independent,coarse_route_endpoints=len(endpoints)),indent=2))
if __name__=='__main__':main()
