"""Compact 2x2 transfer figure; training records are not changed."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter
from fig_style import FIGWIDTH,initialize,axes_style,panel_title,save,BLUE
initialize()
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'data/Figure5';OUT=ROOT/'reproduced/figures/fig_transfer'
fig,axes=plt.subplots(2,2,figsize=(FIGWIDTH,3.32))
fig.subplots_adjust(left=.18,right=.965,bottom=.14,top=.858,wspace=.2,hspace=.46)
for row,mode in enumerate(('direct','sequential')):
    records=list(csv.DictReader((DATA/f'fig4_{mode}_points.csv').open(encoding='utf-8-sig')))
    for col,(model,label,depth) in enumerate((('tfim','TFIM',7),('xxx','Heisenberg',20))):
        ax=axes[row,col];data=sorted((r for r in records if r['model']==model),key=lambda r:int(r['N']))
        n=np.array([int(r['N']) for r in data])
        frozen=np.array([float(r['before_infidelity']) for r in data]);trained=np.array([float(r['refined_infidelity']) for r in data])
        ax.plot(n,frozen,color=BLUE,ls='--',lw=1.5,marker='o',ms=3.0,mfc='white',mec=BLUE,mew=.9)
        ax.plot(n,trained,color=BLUE,ls='-',lw=1.65,marker='D',ms=3.0,mfc=BLUE,mec=BLUE)
        ax.set_yscale('log');ax.set_xlim(5.8,12.2);ax.set_xticks([6,9,12]);ax.set_ylim((.002,.035) if model=='tfim' else (.0032,.7))
        if model=='tfim':
            ax.set_yticks([.003,.01,.03]);ax.yaxis.set_major_formatter(FuncFormatter(lambda a,_: {0.003:'0.003',.01:'0.01',.03:'0.03'}.get(a,'')))
        else:
            ax.set_yticks([.01,.1]);ax.yaxis.set_major_formatter(FuncFormatter(lambda a,_: {0.01:'0.01',.1:'0.1'}.get(a,'')))
            # keep independent scale but suppress repeated ylabel; retains all data points
        panel_title(ax,f'({"abcd"[row*2+col]}) {label}'+(' · Direct' if col==0 and row==0 else ' · Sequential' if col==0 else ''))
        if col==0:ax.set_ylabel(r'Infidelity $1-F$',labelpad=1.6)
        if row==1:ax.set_xlabel(r'Size $N$',labelpad=2)
        axes_style(ax)
fig.legend([Line2D([0],[0],c=BLUE,ls='--',lw=1.5,marker='o',mfc='white',mec=BLUE,ms=3.2),
            Line2D([0],[0],c=BLUE,ls='-',lw=1.6,marker='D',mfc=BLUE,ms=3.2)],
           ['No post-training','Post-trained'],loc='upper center',bbox_to_anchor=(.56,.985),ncol=2,
           frameon=False,fontsize=6.5,handlelength=1.7,columnspacing=1.0,handletextpad=.4)
save(fig,OUT)
