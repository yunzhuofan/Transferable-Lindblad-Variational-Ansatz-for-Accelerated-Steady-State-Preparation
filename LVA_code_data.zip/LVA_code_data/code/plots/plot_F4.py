"""Single-column mechanism panels. Plot the stored diagnostics without recomputation.
The original numerical implementation is preserved in code/physics/ and the
immutable data/Figure4/diagnostics.json.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from fig_style import FIGWIDTH,initialize,axes_style,panel_title,save,SHADES,BLUE,INK
initialize()
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reproduced/figures/fig_preimage'
data=json.loads((ROOT/'data/Figure4/diagnostics.json').read_text())
fig=plt.figure(figsize=(FIGWIDTH,3.32))
top=fig.add_axes([.18,.62,.78,.255]);left=fig.add_axes([.18,.235,.345,.24]);right=fig.add_axes([.625,.235,.335,.24])
rate_colors=[SHADES[0],SHADES[1],SHADES[2]]; styles=['-','--','-.'];markers=['o','s','^']
B=np.arange(3*data['P']+1); t=np.asarray(data['scan_normalized_time'])
top.axhline(1,c='#8997A6',lw=.9,ls=(0,(3,2)))
top.axvspan(B[-2],B[-1],fc='#E5EFF7',alpha=.95,zorder=0)
for g,color,ls,marker in zip(data['selected_groups'],rate_colors,styles,markers):
    top.plot(B,g['path_amplitude'],c=color,ls=ls,lw=1.45,marker=marker,ms=2.35,markevery=3)
    top.scatter(B[-2],g['required_pre_amplitude'],marker='D',s=18,edgecolors=color,facecolors='white',linewidths=.85,zorder=5)
    left.semilogy(t,g['scan_relative_error'],c=color,ls=ls,lw=1.45)
    left.scatter(g['best_time_over_tau'],g['minimum_relative_error'],marker=marker,s=16,c=color,ec='white',lw=.4,zorder=5)
peak=max(max(g['path_amplitude']) for g in data['selected_groups'])
top.set(xlim=(-.2,21.45),ylim=(0,max(8.7,peak*1.08)),xticks=[0,7,14,21],yticks=[0,4,8])
top.set_xlabel(r'Block count $B$',labelpad=2)
top.set_ylabel(r'$\|\mathcal{P}_g\rho_B\|/\|C_g\|$',labelpad=1)
panel_title(top,'(a) Preparing target modes')
top.text(.985,.89,r'$\diamond$ preimage',transform=top.transAxes,ha='right',va='top',fontsize=6.5,color=INK)
left.axvline(1,c='#8193A4',ls=(0,(2,2)),lw=.9)
left.set(xlim=(0,2),xticks=[0,1,2],ylim=(.008,2.0),yticks=[.01,.1,1])
left.set_xlabel(r'Time $t/\tau_f$',labelpad=2);left.set_ylabel(r'Mismatch $r_g$',labelpad=1.2)
panel_title(left,'(b) Shared arrival time')
left.yaxis.set_major_formatter(matplotlib.ticker.LogFormatterMathtext(10))
right.semilogy(t,data['learned_scan_infidelity'],c=SHADES[0],lw=1.6,ls='-',label='Prepared')
right.semilogy(t,data['natural_scan_infidelity'],c=SHADES[2],lw=1.6,ls='--',label='Natural')
right.axvline(1,c='#8193A4',ls=(0,(2,2)),lw=.9)
right.set(xlim=(0,2),ylim=(.0013,.17),xticks=[0,1,2],yticks=[.01,.1])
right.set_xlabel(r'Time $t/\tau_f$',labelpad=2)
panel_title(right,'(c) Endpoint infidelity')
right.legend(frameon=False,loc='upper left',fontsize=6.15,handlelength=1.5,handletextpad=.35,borderaxespad=.6)
for ax in (top,left,right):axes_style(ax)
fig.legend([Line2D([0],[0],c=c,lw=1.4,ls=s) for c,s in zip(rate_colors,styles)],
           [r'$\Gamma=0.5$',r'$2$',r'$4$'],loc='upper center',bbox_to_anchor=(.55,.986),
           frameon=False,ncol=3,fontsize=6.6,handlelength=1.5,handletextpad=.4,columnspacing=1.15)
save(fig,OUT)
