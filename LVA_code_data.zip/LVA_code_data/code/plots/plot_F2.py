"""Single-column Fig. 2. All displayed series are read from archived JSON/CSV."""
from pathlib import Path
import json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from fig_style import FIGWIDTH, initialize, axes_style, log_y, panel_title, save, BLUE,ORANGE,TEAL,PURPLE,GRAY
initialize()
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reproduced/figures/fig2'
DATA=ROOT/'data/Figure2'
fig, axes=plt.subplots(2,2,figsize=(FIGWIDTH,3.64))
fig.subplots_adjust(left=.175,right=.970,bottom=.135,top=.862,hspace=.74,wspace=.18)
training={m:json.loads((DATA/f'training_{m}.json').read_text()) for m in ('tfim','xxx')}
base=list(csv.DictReader((DATA/'plotted_points_maxiter1000.csv').open()))
for col,mode in enumerate(('tfim','xxx')):
    label='TFIM' if mode=='tfim' else 'Heisenberg'
    data=training[mode]
    ax=axes[0,col];panel_title(ax,f'({"ab"[col]}) {label}')
    for typ,color,mrk,lw in [('augmented',TEAL,'o',1.7),('plain',PURPLE,'D',1.2)]:
        points=data[typ]
        ax.plot([float(r['B']) for r in points],[float(r['training_infidelity']) for r in points],
                c=color,lw=lw,marker=mrk,ms=2.3,markevery=max(1,len(points)//8))
    rr=data['random']; depths=sorted({r['P'] for r in rr})
    best=[min(r['training_infidelity'] for r in rr if r['P']==p) for p in depths]
    worst=[max(r['training_infidelity'] for r in rr if r['P']==p) for p in depths]
    ax.fill_between(3*np.asarray(depths),best,worst,color=GRAY,alpha=.13,lw=0)
    ax.plot(3*np.asarray(depths),best,c=GRAY,marker='s',lw=1.1,ms=2.7)
    ax.set_ylim(1e-6,1.2)
    ax.set_xlim(0,62 if mode=='tfim' else 153)
    ax.set_xticks([0,30,60] if mode=='tfim' else [0,75,150])
    ax.set_xlabel(r'Block count $B$',labelpad=2)
    if col==0: ax.set_ylabel(r'Infidelity $1-F$',labelpad=1)
    else:ax.tick_params(labelleft=False)
    log_y(ax,[1,1e-2,1e-4,1e-6]);axes_style(ax)
    ax=axes[1,col];panel_title(ax,f'({"cd"[col]}) {label}')
    for order,color,marker in [(1,BLUE,'o'),(2,ORANGE,'s')]:
        vals=[r for r in base if r['model']==mode and r['series']==f'Trotter order {order}']
        xx=np.array([int(r['B']) for r in vals]);yy=np.array([float(r['infidelity']) for r in vals]);yy=np.where(yy>=1e-6,yy,np.nan)
        ax.plot(xx,yy,c=color,lw=1.3,marker=marker,mfc='white',mec=color,mew=.7,
                ms=2.8,markevery=max(1,len(xx)//11))
    points=data['augmented']; yy=np.array([r['training_infidelity'] for r in points]);yy=np.where(yy>=1e-6,yy,np.nan)
    ax.plot([r['B'] for r in points],yy,c=TEAL,lw=1.8,marker='^',ms=3.0,markevery=max(1,len(points)//11))
    ax.set_xscale('log');ax.set_xlim(2,1100);ax.set_xticks([10,100,1000]);
    ax.set_xlabel(r'Block count $B$',labelpad=2)
    ax.set_ylim(1e-6,1.2)
    if col==0:ax.set_ylabel(r'Infidelity $1-F$',labelpad=1)
    else:ax.tick_params(labelleft=False)
    log_y(ax,[1,1e-2,1e-4,1e-6]);axes_style(ax)
# Short legends form two compact bands; caption contains the complete method names.
first=[Line2D([0],[0],c=c,lw=1.4,marker=m,ms=3.1) for c,m in [(TEAL,'o'),(PURPLE,'D'),(GRAY,'s')]]
second=[Line2D([0],[0],c=c,lw=1.4,marker=m,ms=3.1,mfc='white' if c!=TEAL else c) for c,m in [(BLUE,'o'),(ORANGE,'s'),(TEAL,'^')]]
fig.legend(first,['Extended','INTERP','Random'],loc='upper center',bbox_to_anchor=(.55,.994),ncol=3,
           frameon=False,fontsize=6.2,columnspacing=.83,handlelength=1.3,handletextpad=.3)
fig.legend(second,['1st order','2nd order','LVA'],loc='upper center',bbox_to_anchor=(.55,.493),ncol=3,
           frameon=False,fontsize=6.2,columnspacing=.83,handlelength=1.3,handletextpad=.3)
save(fig,OUT)
