"""Single-column resource/gain figure using the saved series and thresholds."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogFormatterMathtext
from fig_style import FIGWIDTH,initialize,axes_style,panel_title,save,BLUE,ORANGE,TEAL
initialize()
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'data/Figure6';OUT=ROOT/'reproduced/figures/fig5'
rows=list(csv.DictReader((DATA/'plotted_points.csv').open(encoding='utf-8-sig')))
gains=list(csv.DictReader((DATA/'sampled_gains_full_data.csv').open(encoding='utf-8-sig')))
styles={'order1':(BLUE,'o','-','white'),'order2':(ORANGE,'s','-','white'),
        'before':(TEAL,'^','--','white'),'refined':(TEAL,'D','-',TEAL)}
fig,axes=plt.subplots(2,2,figsize=(FIGWIDTH,3.58))
fig.subplots_adjust(left=.18,right=.97,bottom=.12,top=.820,wspace=.21,hspace=.52)
for col,(model,label,eps) in enumerate((('tfim','TFIM',.01),('xxx','Heisenberg',.05))):
    ax=axes[0,col];panel_title(ax,rf'({"ab"[col]}) {label}, $N=12$')
    for stage,(c,m,ls,face) in styles.items():
        vals=sorted([r for r in rows if r['model']==model and r['stage']==stage],key=lambda r:int(r['B']))
        ax.plot([int(r['B']) for r in vals],[float(r['infidelity']) for r in vals],
                c=c,lw=1.45,ls=ls,marker=m,ms=2.6,mfc=face,mec=c,mew=.65,markevery=max(1,len(vals)//15))
    ax.axhline(eps,color='#808B92',lw=.85,ls=':')
    ax.set_xscale('log');ax.set_yscale('log');ax.set_xlim(3,1100);ax.set_xticks([10,100,1000]);
    ax.set_ylim((1e-5,1.2) if model=='tfim' else (.02,1.2));ax.set_yticks([1,1e-2,1e-4] if model=='tfim' else [1,.1])
    ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10))
    ax.set_xlabel(r'Block count $B$',labelpad=2)
    if col==0:ax.set_ylabel(r'Infidelity $1-F$',labelpad=1.2)
    axes_style(ax)
    ax=axes[1,col]
    for stage in ('before','refined'):
        vals=sorted([r for r in gains if r['model']==model and r['stage']==stage and r['gain']],key=lambda r:int(r['N']))
        c,m,ls,face=styles[stage]
        ax.plot([int(r['N']) for r in vals],[float(r['gain']) for r in vals],c=c,ls=ls,lw=1.6,
                marker=m,ms=3.1,mfc=face,mec=c,mew=.7)
    ax.axhline(1,c='#8D989F',ls=':',lw=.85)
    ax.set_xlim(4.8,12.2);ax.set_xticks([5,8,12]);ax.set_ylim((.82,2.65) if model=='tfim' else (.82,3.05));ax.set_yticks([1,2] if model=='tfim' else [1,2,3])
    ax.set_xlabel(r'Size $N$',labelpad=2)
    if col==0:ax.set_ylabel(r'Gain $\widehat G_B^{(2)}$',labelpad=1.2)
    panel_title(ax,rf'({"cd"[col]}) {label}, $\epsilon={eps:g}$')
    axes_style(ax)
handles=[Line2D([0],[0],c=c,ls=ls,lw=1.4,marker=m,mfc=face,ms=3) for c,m,ls,face in styles.values()]
fig.legend(handles,['1st order','2nd order','No post-training','Post-trained'],loc='upper center',
           bbox_to_anchor=(.555,.997),ncol=2,frameon=False,fontsize=6.4,
           handlelength=1.35,handletextpad=.3,columnspacing=1.3,labelspacing=.32)
save(fig,OUT)
