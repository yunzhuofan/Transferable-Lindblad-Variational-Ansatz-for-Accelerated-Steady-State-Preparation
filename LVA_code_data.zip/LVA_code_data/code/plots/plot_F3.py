"""Fig. 3 modal diagnosis: 2x2 model-by-protocol grid at publication width."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from fig_style import FIGWIDTH, initialize, axes_style, log_y, panel_title, save, SHADES
initialize()
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reproduced/figures/fig3'
fig,axes=plt.subplots(2,2,figsize=(FIGWIDTH,3.45))
fig.subplots_adjust(left=.172,right=.975,bottom=.205,top=.905,wspace=.20,hspace=.50)
styles=['-','--','-.',(0,(1.0,1.55))]
# Line styles, not symbols, distinguish the four mode groups at column width.
colors=['#102945','#245B8F','#397EAA','#6A9EB9']
for row,model in enumerate(('tfim','xxx')):
    d=json.loads((ROOT/f'data/Figure3/{model}_spectrum_modes.json').read_text())
    for col,natural in enumerate((True,False)):
        ax=axes[row,col]
        tag='abcd'[row*2+col]
        panel_title(ax,f'({tag}) {"TFIM" if model=="tfim" else "Heisenberg"} · {"Natural" if natural else "LVA"}')
        if natural:
            t=np.asarray(d['exact_t']); end=12 if model=='tfim' else 30
            keep=t<=end+1e-10;xx=t[keep];yy=np.asarray(d['natural_weight'])[:,keep]
            ax.set_xlim(0,end);ax.set_xticks([0,end/2,end])
        else:
            xx=np.asarray(d['B']);yy=np.asarray(d['weight']);end=float(xx[-1]);
            ax.set_xlim(-.02*end,1.03*end);ax.set_xticks([0,10,21] if model=="tfim" else [0,30,60])
        for k,(color,style) in enumerate(zip(colors,styles)):
            y=yy[k]; yp=np.where(y>=1e-4,y,np.nan)
            ax.plot(xx,yp,color=color,ls=style,
                    lw=1.65 if not natural else 1.4,
                    solid_capstyle='round',dash_capstyle='round', zorder=3+k)
            if (not natural) and y[-1]<1e-4:
                ax.plot(xx[-1],1e-4,marker='v',ms=2.45,color=color,
                        markeredgecolor='white',markeredgewidth=.45,zorder=5+k)
        ax.set_ylim(8e-5,5)
        log_y(ax,[1,1e-2,1e-4]);axes_style(ax)
        if col==1:ax.tick_params(labelleft=False)
        if row==1:ax.set_xlabel(r'Time $\gamma t$' if natural else r'Block count $B$',labelpad=2)
        if col==0:ax.set_ylabel(r'Mode amplitude $W_g$',labelpad=1.2)
handles=[Line2D([0],[0],c=c,ls=s,lw=1.85) for c,s in zip(colors,styles)]
fig.legend(handles,['Slowest','Slow','Mid','Fast'],loc='lower center',bbox_to_anchor=(.53,.025),
           frameon=False,ncol=4,fontsize=6.2,handlelength=1.75,handletextpad=.32,columnspacing=.8)
save(fig,OUT)
