"""Compact, publication-scale figure settings for single-column REVTeX layout.
Only typography and plotting are changed; scientific series come from archived data.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator, NullFormatter, LogFormatterMathtext, FixedLocator

FIGWIDTH = 3.38
INK = '#263343'
BLUE = '#27699C'
ORANGE = '#CE7A34'
TEAL = '#087E72'
PURPLE = '#8068A8'
GRAY = '#798690'
PALE = '#DAE4ED'
SHADES = ['#102945', '#255E92', '#4888BA', '#90BBD5']


def initialize():
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'mathtext.fontset': 'stix',
        'font.size': 7.0, 'axes.labelsize': 7.0, 'axes.titlesize': 7.25,
        'xtick.labelsize': 6.3, 'ytick.labelsize': 6.3,
        'legend.fontsize': 6.4, 'axes.linewidth': .72,
        'lines.linewidth': 1.45, 'lines.markersize': 3,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
        'savefig.facecolor': 'white', 'figure.facecolor': 'white',
    })


def axes_style(ax, grid=True):
    for side in ['top', 'right']:
        ax.spines[side].set_visible(False)
    ax.tick_params(direction='out', length=2.3, width=.6, pad=1.6)
    ax.xaxis.set_minor_locator(NullLocator())
    ax.yaxis.set_minor_locator(NullLocator())
    if grid:
        ax.grid(axis='y', color='#DFE7ED', linewidth=.55, zorder=0)
        ax.set_axisbelow(True)


def log_y(ax, ticks):
    ax.set_yscale('log')
    ax.set_yticks(ticks)
    ax.yaxis.set_major_formatter(LogFormatterMathtext(10))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.yaxis.set_minor_formatter(NullFormatter())


def panel_title(ax, text):
    ax.set_title(text, loc='left', pad=3.6, color=INK, fontweight='semibold', fontsize=7.1)


def save(fig, path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path.with_suffix('.pdf'))
    fig.savefig(path.with_suffix('.svg'))
    fig.savefig(path.with_suffix('.png'), dpi=300)
    plt.close(fig)
