"""Recompute Figure 4 from the archived TFIM source controls; no retraining."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ.setdefault(key,'1')
from pathlib import Path
import csv, hashlib, json
import numpy as np
import scipy.linalg as la
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve, expm_multiply
from scipy.optimize import brentq,minimize_scalar
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'reproduced/preimage'
SOURCE=ROOT/'data/Figure3'
N,DIM=5,32
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def embed(a, site):
    out = np.array([[1.0]])
    for j in range(N):
        out = np.kron(out, a if j == site else np.eye(2))
    return out.astype(complex)

def local_map(rho, site, kind, eta=None):
    """Exact amplitude-damping channel or one of its algebraic projectors."""
    a = np.moveaxis(rho.reshape((2,)*(2*N)), (site, N+site), (0, 1))
    b = np.zeros_like(a)
    if kind == 'channel':
        b[0, 0] = eta*a[0, 0]
        b[0, 1] = np.sqrt(eta)*a[0, 1]
        b[1, 0] = np.sqrt(eta)*a[1, 0]
        b[1, 1] = a[1, 1]+(1-eta)*a[0, 0]
    elif kind == 0:
        b[1, 1] = a[0, 0]+a[1, 1]
    elif kind == 1:
        b[0, 1], b[1, 0] = a[0, 1], a[1, 0]
    else:
        b[0, 0], b[1, 1] = a[0, 0], -a[0, 0]
    return np.moveaxis(b, (0, 1), (site, N+site)).reshape(DIM, DIM)

def damping(rho, t):
    for site in range(N):
        rho = local_map(rho, site, 'channel', np.exp(-t))
    return rho

def project(rho):
    """Convolve local rates 0, 1/2, 1 to retain every dissipative spectral group."""
    groups = {0: rho}
    for site in range(N):
        new = {}
        for k, a in groups.items():
            for label in range(3):
                value = local_map(a, site, label)
                new[k+label] = new.get(k+label, 0)+value
        groups = new
    return np.array([groups[k] for k in range(2*N+1)])

def recompute():
    DEST.mkdir(parents=True,exist_ok=True)
    controls_path = SOURCE/'selected_controls_tfim.json'
    states_path = SOURCE/'tfim_trajectory.npz'
    chosen = json.loads(controls_path.read_text())
    assert chosen['maxiter'] == 1000 and chosen['objective'] == '1 - squared Uhlmann fidelity'
    parameters = np.array(chosen['record']['parameters'])
    assert parameters.shape == (7, 3)
    source_hashes = {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p)
                     for p in [controls_path, states_path]}
    x = np.array([[0, 1], [1, 0]], complex)
    z = np.diag([1, -1]).astype(complex)
    jump = np.array([[0, 0], [1, 0]], complex)
    h1 = sum(embed(x, j) for j in range(N))
    h2 = sum(embed(z, j)@embed(z, j+1) for j in range(N-1))
    ident = sp.eye(DIM, format='csc', dtype=complex)
    h = sp.csc_matrix(h1+h2)
    coherent = -1j*(sp.kron(ident, h)-sp.kron(h.T, ident))
    dissipator = sp.csc_matrix((DIM*DIM, DIM*DIM), dtype=complex)
    for j in range(N):
        op = sp.csc_matrix(embed(jump, j)); q = op.conj().T@op
        dissipator += sp.kron(op.conj(), op)-0.5*sp.kron(ident, q)-0.5*sp.kron(q.T, ident)
    lindblad = (coherent+dissipator).tocsc()
    stationary = lindblad.tolil(copy=True)
    stationary[0, :] = 0
    stationary[0, np.arange(DIM)*(DIM+1)] = 1
    rhs = np.zeros(DIM*DIM, complex); rhs[0] = 1
    reference = spsolve(stationary.tocsc(), rhs).reshape(DIM, DIM, order='F')
    reference = (reference+reference.conj().T)/2
    reference /= np.trace(reference)
    values, vectors = la.eigh(reference)
    sqrtref = (vectors*np.sqrt(np.maximum(values, 0)))@vectors.conj().T

    def infidelity(rho):
        a = sqrtref@rho@sqrtref
        return float(1-np.sqrt(np.maximum(la.eigvalsh((a+a.conj().T)/2), 0)).sum()**2)

    rho0 = np.zeros((DIM, DIM), complex); rho0[-1, -1] = 1
    states = [rho0.copy()]
    rho = rho0.copy()
    for a, b, tau in parameters:
        for angle, ham in [(a, h1), (b, h2)]:
            u = la.expm(-1j*angle*ham)
            rho = u@rho@u.conj().T; states.append(rho.copy())
        rho = damping(rho, tau); states.append(rho.copy())
    states = np.array(states)
    with np.load(states_path) as old:
        assert np.array_equal(parameters, old['parameters'])
        trajectory_difference = float(np.max(np.abs(states-old['states'])))
        reference_difference = float(la.norm(reference-old['reference']))
    assert trajectory_difference < 1e-12 and reference_difference < 1e-12
    pre = states[-2]; tau = float(parameters[-1, 2])
    c = project(reference); a = project(pre)
    components = np.array([project(rho) for rho in states])
    rates = np.arange(2*N+1)/2
    pre_error = infidelity(pre)

    def natural(t):
        return expm_multiply(t*lindblad, rho0.reshape(-1, order='F')).reshape(DIM, DIM, order='F')

    high = 1.0
    while infidelity(natural(high)) > pre_error:
        high *= 2
    match_time = float(brentq(lambda t: infidelity(natural(t))-pre_error, 0, high, xtol=1e-13))
    control = natural(match_time)
    normalized = np.linspace(0, 2, 401)
    learned_scan = np.array([damping(pre, t*tau) for t in normalized])
    natural_scan = np.array([damping(control, t*tau) for t in normalized])
    learned_errors = np.array([infidelity(rho) for rho in learned_scan])
    natural_errors = np.array([infidelity(rho) for rho in natural_scan])
    # Select from target components before inspecting any mismatch or optimal time.
    # Cover the slow/middle/fast part with appreciable target norm. Resolve a
    # midpoint tie by the larger target norm; these norms are not probabilities.
    target_norms = np.linalg.norm(c, axis=(1, 2))
    threshold = 0.1*max(target_norms[1:])
    eligible = [k for k in range(1, len(rates)) if target_norms[k] >= threshold]
    low, high = eligible[0], eligible[-1]
    midpoint = (rates[low]+rates[high])/2
    middle = min(eligible[1:-1], key=lambda k: (abs(rates[k]-midpoint), -target_norms[k]))
    selected_rates = [float(rates[k]) for k in [low, middle, high]]
    groups = []
    for rate in selected_rates:
        k = int(2*rate); aa, cc = a[k], c[k]
        an, cn = la.norm(aa), la.norm(cc)
        cosine = float(np.vdot(aa, cc).real/(an*cn))
        q = float(np.vdot(aa, cc).real/an**2)
        assert 0 < q < 1
        best = float(-np.log(q)/rate)
        relative = np.array([la.norm(np.exp(-rate*t*tau)*aa-cc)/cn for t in normalized])
        amplitude = np.exp(-rate*normalized*tau)*an/cn
        identity = (amplitude-1)**2+2*amplitude*(1-cosine)
        numerical = minimize_scalar(lambda t: (la.norm(np.exp(-rate*t)*aa-cc)/cn)**2,
                                    bounds=(0, 2*tau), method='bounded', options={'xatol': 1e-14})
        assert abs(numerical.x-best) < 1e-7
        assert np.max(np.abs(identity-relative**2)) < 1e-12
        groups.append(dict(rate=rate, target_norm=float(cn), pre_amplitude=float(an/cn),
                           required_pre_amplitude=float(np.exp(rate*tau)), cosine=cosine, q=q,
                           best_time=best, best_time_over_tau=best/tau,
                           minimum_relative_error=float(la.norm(np.exp(-rate*best)*aa-cc)/cn),
                           path_amplitude=(np.linalg.norm(components[:, k], axis=(1, 2))/cn).tolist(),
                           scan_relative_error=relative.tolist(),
                           amplitude_direction_identity_max_error=float(np.max(np.abs(identity-relative**2)))))
    projection_residual = max(float(la.norm((dissipator@c[k].reshape(-1, order='F')).reshape(DIM, DIM, order='F')+rate*c[k]))
                              for k, rate in enumerate(rates))
    sparse_final = expm_multiply(tau*dissipator, pre.reshape(-1, order='F')).reshape(DIM, DIM, order='F')
    projection_channel_difference = max(float(la.norm(project(learned_scan[113])[k]-np.exp(-rate*normalized[113]*tau)*a[k]))
                                       for k, rate in enumerate(rates))
    all_states = np.concatenate([states, learned_scan, natural_scan])
    checks = dict(saved_trajectory_max_abs_difference=trajectory_difference,
                  saved_reference_frobenius_difference=reference_difference,
                  stationary_residual=float(la.norm(lindblad@reference.reshape(-1, order='F'))),
                  spectral_reconstruction_error=float(np.max(np.abs(components.sum(axis=1)-states))),
                  spectral_eigenrelation_error=projection_residual,
                  projected_channel_error=projection_channel_difference,
                  independent_sparse_terminal_error=float(la.norm(sparse_final-states[-1])),
                  equal_input_infidelity_difference=float(abs(infidelity(control)-pre_error)),
                  max_trace_error=float(np.max(np.abs(np.trace(all_states, axis1=1, axis2=2)-1))),
                  max_hermiticity_error=float(np.max(np.abs(all_states-all_states.conj().transpose(0, 2, 1)))),
                  minimum_state_eigenvalue=float(min(la.eigvalsh(rho).min() for rho in all_states)))
    assert all(value < 1e-10 for key, value in checks.items() if key != 'minimum_state_eigenvalue')
    assert checks['minimum_state_eigenvalue'] > -1e-12
    data = dict(model='tfim', N=N, P=7, maxiter=1000, source_loss=chosen['objective'], tau=tau,
                source_sha256=source_hashes, 
                rate_selection={'relative_target_norm_threshold': 0.1,
                                'all_rates': rates.tolist(), 'all_target_norms': target_norms.tolist(),
                                'eligible_rates': rates[eligible].tolist(), 'selected_rates': selected_rates,
                                'rule': 'slowest and fastest eligible rates; nearest to their midpoint, with larger-target-norm tie break'},
                fresh_recomputation=True, retraining=False, pre_infidelity=pre_error,
                endpoint_infidelity=infidelity(states[-1]), natural_matching_time=match_time,
                natural_endpoint_infidelity=infidelity(damping(control, tau)),
                scan_normalized_time=normalized.tolist(), learned_scan_infidelity=learned_errors.tolist(),
                natural_scan_infidelity=natural_errors.tolist(), selected_groups=groups, checks=checks)
    dump(DEST/'diagnostics.json', data)
    np.savez_compressed(DEST/'states_and_projections.npz', parameters=parameters, states=states,
                        reference=reference, natural_input=control, rates=rates, target_groups=c,
                        pre_groups=a, path_groups=components, learned_scan=learned_scan,
                        natural_scan=natural_scan, normalized_time=normalized)
    rows = []
    for group in groups:
        for b, value in enumerate(group['path_amplitude']):
            rows.append(dict(panel='a', rate=group['rate'], x=b, y=value))
        rows.extend(dict(panel='b', rate=group['rate'], x=float(t), y=value)
                    for t, value in zip(normalized, group['scan_relative_error']))
    for method, errors in [('LVA', learned_errors), ('natural', natural_errors)]:
        rows.extend(dict(panel='c', rate=method, x=float(t), y=float(value)) for t, value in zip(normalized, errors))
    with (DEST/'plotted_points.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=['panel', 'rate', 'x', 'y']); writer.writeheader(); writer.writerows(rows)
    assert all(sha(ROOT/path) == digest for path, digest in source_hashes.items())
    print(json.dumps({key: data[key] for key in ['tau', 'pre_infidelity', 'endpoint_infidelity', 'natural_endpoint_infidelity', 'checks']}, indent=2))
    return data

if __name__=='__main__':recompute()
