"""Recompute the linear-response columns of Table S7 from its saved r and J."""
from pathlib import Path
import sys,json,csv
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code/physics'))
from response_analysis import projection

def main():
    rows=[]
    for model,depth in [('tfim',7),('xxx',20)]:
        summary=json.loads((ROOT/f'data/Response/{model}/summary.json').read_text())
        free=summary['free_coordinates']
        source=np.load(ROOT/f'data/Response/{model}/response_{model}_P{depth}_N5.npz')['J'][:,free]
        eig,vec=np.linalg.eigh(source.T@source);order=np.argsort(eig)[::-1]
        eig,vec=eig[order][:6],vec[:,order][:,:6]
        whiten=np.diag(1/np.sqrt(eig))
        for saved in summary['rows']:
            n=saved['N'];data=np.load(ROOT/f'data/Response/{model}/response_{model}_P{depth}_N{n}.npz')
            r,J=data['r'],data['J'][:,free];A=J@vec
            eta=float(np.linalg.eigvalsh(whiten@(A.T@A)@whiten)[0])
            chi6=projection(A,r)[0];chi_all=projection(J,r)[0]
            expected=next(x for x in saved['direction_results'] if x['k']==6)
            assert abs(eta-expected['relative_gram_eigenvalue_min'])<1e-9
            assert abs(chi6-expected['source_subspace_correctable_fraction'])<1e-9
            assert abs(chi_all-saved['full_correctable_fraction'])<1e-9
            step=saved['full_one_step']
            rows.append(dict(model=model,N=n,eta=eta,chi6=chi6,chi_all=chi_all,
                             cost_reduction=step['fraction_removed_actual'],infidelity_after=step['infidelity_after']))
    out=ROOT/'reproduced';out.mkdir(exist_ok=True)
    with (out/'Table_S7.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('Verified and reconstructed all 16 Table S7 response rows.')

if __name__=='__main__':main()
