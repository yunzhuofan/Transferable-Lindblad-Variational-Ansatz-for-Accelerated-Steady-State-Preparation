"""Numerical entry points using the exact model/channel/gradient kernels."""
from pathlib import Path
import argparse,json,os,sys
for name in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(name,'1')
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code/physics'))
import numpy as np
from scipy.optimize import minimize
from lva_core import Model
from xxx_blocks import XXXBlocks
from lva_local_cost import local_cost_grad
from block_losses import BlockLoss

def cpu(model,n):return Model(n,'tfim') if model=='tfim' else XXXBlocks(n)

def reference(model,n):
    out=ROOT/'reproduced/references';out.mkdir(parents=True,exist_ok=True)
    if n<=9:
        m=cpu(model,n);state,check=m.steady_state(out)
        return m,check
    import extension_backend as b
    from fast_exact import FastHeisenberg
    cp=b.cp
    m=b.Tfim(n,reference=False) if model=='tfim' else FastHeisenberg(n,reference=False)
    path=out/f'{model}_N{n}.npz'
    if path.exists():m.set_reference(np.load(path)['state'],path);return m,m.reference_checks
    if model=='tfim':
        m.p.prepare_reference();state=m.p.xss
    else:
        from cupyx.scipy.sparse.linalg import LinearOperator,gmres
        diag=cp.concatenate([cp.eye(int(d),dtype=cp.complex128).ravel(order='F') for d in m.ds])
        uniform=diag/(2**n)
        op=LinearOperator((m.dim,m.dim),matvec=lambda z:-m.generator(z)+uniform*cp.vdot(diag,z),dtype=cp.complex128)
        state,flag=gmres(op,uniform,x0=uniform,rtol=0.,atol=1e-12,restart=20,maxiter=12000)
        if flag:raise RuntimeError(f'GMRES has not converged: {flag}')
        state=m.pack([(x+x.conj().T)/2 for x in m.views(state)]);state/=m.trace(state)
    np.savez_compressed(path,state=b.host(state));m.set_reference(state,path)
    return m,m.reference_checks

def refine(model,route,depth,with_reference=False):
    trained=json.loads((ROOT/f'data/Figure2/training_{model}.json').read_text())
    pool=trained['augmented']+json.loads((ROOT/'data/Figure6/source_extensions.json').read_text())
    par=np.asarray(next(r['parameters'] for r in pool if r.get('model',model)==model and r['P']==depth)).ravel()
    records=[];region=2 if model=='tfim' else 4
    for n in route[1:]:
        if n<=9:
            m=cpu(model,n)
            if with_reference:m.steady_state(ROOT/'reproduced/references')
            fn=(lambda x:local_cost_grad(m,x,region)) if model=='tfim' else BlockLoss(m,'local',region)
        else:
            import extension_backend as b
            from fast_exact import FastHeisenberg
            m=b.Tfim(n,reference=False) if model=='tfim' else FastHeisenberg(n,reference=False)
            if with_reference:m,_=reference(model,n)
            fn=m.cost_grad
        before=par.copy()
        opt=minimize(fn,par,jac=True,method='L-BFGS-B',bounds=[(-np.pi,np.pi),(-np.pi,np.pi),(0,4)]*depth,
                     options={'maxiter':1000,'gtol':1e-10,'ftol':1e-14,'maxls':30})
        par=opt.x.copy()
        row={'model':model,'N':n,'P':depth,'initial_parameters':before.tolist(),'parameters':par.reshape(-1,3).tolist(),
             'iterations':int(opt.nit),'nfev':int(opt.nfev),'local_loss':float(opt.fun),
             'success':bool(opt.success),'message':str(opt.message)}
        if with_reference:
            row['metrics']=m.metrics(m.state(par),trace_distance=False) if n<=9 else m.metrics(m.state(par))
        records.append(row)
    out=ROOT/'reproduced';out.mkdir(exist_ok=True)
    dest=out/f'route_{model}_{"_".join(map(str,route))}.json'
    dest.write_text(json.dumps(records,indent=2)+'\n');print(dest)

def smoke():
    from response_core import response,residual_vector
    results=[]
    for model,p in [('tfim',7),('xxx',20)]:
        d=json.loads((ROOT/f'data/Figure2/training_{model}.json').read_text())
        par=np.asarray(next(r['parameters'] for r in d['augmented'] if r['P']==p)).ravel()
        m=cpu(model,3);r,J,_=response(m,par,2)
        _,grad=local_cost_grad(m,par,2) if model=='tfim' else BlockLoss(m,'local',2)(par)
        err=0
        for k in range(len(par)):
            plus=par.copy();minus=par.copy();plus[k]+=1e-6;minus[k]-=1e-6
            fd=(residual_vector(m,m.state(plus),2)-residual_vector(m,m.state(minus),2))/(2e-6)
            err=max(err,float(np.max(np.abs(fd-J[:,k]))))
        adj=float(np.max(np.abs(grad-2*J.T@r)))
        assert err<1e-7 and adj<1e-10
        results.append({'model':model,'Jacobian_error':err,'adjoint_error':adj})
    print(json.dumps(results,indent=2))

def bulk():
    from response_core import response
    reports=[]
    for par,region,sizes in [(np.array([1.1,-.7,.45]),2,list(range(6,13))),
                             (np.array([1.1,-.7,.45,.9,.4,.6]),1,list(range(7,13)))]:
        vals=[]
        for n in sizes:
            if n<=9:r,J,_=response(Model(n,'tfim'),par,region)
            else:
                from gpu_response import Adapter,response as gpu_response
                r,J,_=gpu_response(Adapter('tfim',n),par,region)
            vals.append({'N':n,'C':float(r@r),'K':J.T@J,'b':J.T@r})
        x=1/(np.asarray(sizes)-region+1);errors=[]
        for k in range(2,len(vals)):
            error={name:float(np.max(np.abs(vals[0][name]+(x[k]-x[0])/(x[1]-x[0])*(vals[1][name]-vals[0][name])-vals[k][name]))) for name in ['C','K','b']}
            errors.append({'N':sizes[k],'errors':error})
        reports.append({'P':len(par)//3,'r':region,'errors':errors})
    out=ROOT/'reproduced';out.mkdir(exist_ok=True);(out/'bulk_checks.json').write_text(json.dumps(reports,indent=2)+'\n')
    print(json.dumps(reports,indent=2))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['refine','reference','response-check','bulk'])
    parser.add_argument('--model',choices=['tfim','xxx'],default='tfim')
    parser.add_argument('--N',type=int,default=5)
    parser.add_argument('--P',type=int)
    parser.add_argument('--route',default='5,12')
    parser.add_argument('--with-reference',action='store_true')
    args=parser.parse_args()
    (ROOT/'reproduced/references').mkdir(parents=True,exist_ok=True)
    if args.action=='reference':print(reference(args.model,args.N)[1])
    elif args.action=='refine':
        route=list(map(int,args.route.split(',')));assert route[0]==5 and route==sorted(set(route))
        refine(args.model,route,args.P or (7 if args.model=='tfim' else 20),args.with_reference)
    elif args.action=='bulk':bulk()
    else:smoke()

if __name__=='__main__':main()
