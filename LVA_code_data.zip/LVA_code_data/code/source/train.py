"""Retrain Figure 2 source comparisons with infidelity; leave paper untouched."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import argparse, json, time, hashlib
import numpy as np
from scipy.optimize import minimize
from fidelity_objective import Model, interpolate, loss_grad, CODE
from lva_advanced import strang_parameters

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reproduced/source'
DATA=ROOT/'data/source_inputs'
def read(path): return json.loads(path.read_text())
def save(path,obj):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(obj,indent=2));temp.replace(path)

def run(model_name, iterations=1000, output_dir=None):
    output=Path(output_dir).resolve() if output_dir is not None else OUT
    output.mkdir(parents=True,exist_ok=True)
    maximum=20 if model_name=='tfim' else 50
    model=Model(5,model_name);_,checks=model.steady_state(DATA)
    raw=read(DATA/f'source_{model_name}_N5_seed0.json')['records']
    baseline=read(DATA/f'benchmark_{model_name}_N5.json')['baselines']
    path=output/f'training_{model_name}.json'
    result=read(path) if path.exists() else {
        'model':model_name,'N':5,'objective':'1 - squared Uhlmann fidelity',
        'maximum_depth':maximum,'iterations_per_candidate':iterations,
        'bounds':[[-float(np.pi),float(np.pi)],[-float(np.pi),float(np.pi)],[0,4]],
        'reference_checks':checks,'augmented':[],'plain':[],'random':[],
        'source_only':True,'legacy_candidates':'Original residual schedules and source Strang schedules reused only as initial parameters; every candidate optimized with infidelity.',
        'inputs_sha256':{f:hashlib.sha256((DATA/f).read_bytes()).hexdigest() for f in [f'source_{model_name}_N5_seed0.json',f'benchmark_{model_name}_N5.json',f'reference_{model_name}_N5.npz']}}
    if result['iterations_per_candidate'] != iterations:
        raise ValueError('Cannot resume a checkpoint with a different iteration cap')
    fn=lambda x:loss_grad(model,x)
    def optimize(start,label,P):
        initial=fn(start)[0];tic=time.perf_counter()
        opt=minimize(fn,start,jac=True,method='L-BFGS-B',bounds=[(-np.pi,np.pi),(-np.pi,np.pi),(0,4)]*P,
            options={'maxiter':iterations,'gtol':1e-10,'ftol':1e-14,'maxls':30})
        return opt,{'candidate':label,'initial_infidelity':initial,'final_infidelity':float(opt.fun),
            'nit':int(opt.nit),'nfev':int(opt.nfev),'success':bool(opt.success),'message':str(opt.message),'seconds':time.perf_counter()-tic}
    def record(P,par,value,**extra):
        rho=model.state(par);metrics=model.metrics(rho,trace_distance=True)
        error=abs(value-metrics['infidelity'])
        if error>2e-7:raise ArithmeticError(f'Objective/independent metric mismatch {error}')
        return {'P':P,'B':3*P,'training_infidelity':float(value),'parameters':np.asarray(par).reshape(-1,3).tolist(),
                'metrics':metrics,'HS_state_error':float(np.linalg.norm(rho-model.ss)**2),
                'minimum_eigenvalue':float(np.linalg.eigvalsh((rho+rho.conj().T)/2).min()),**extra}
    # Replaying RNG consumption makes resuming reproducible.
    rng=np.random.default_rng(10)
    previous=None
    for P in range(1,maximum+1):
        if previous is None:
            starts=[('initial',np.full(3,.1)),('random seed',np.r_[rng.uniform(-1,1,2),rng.uniform(.1,1)])]
        else:
            interp=interpolate(previous)
            starts=[('INTERP',interp.ravel()),('identity insertion',np.r_[previous.ravel(),[0.,0.,0.]])]
            if P in [3,5,7,9,12,16,20,24,30]:
                pert=interp.copy();pert[:,:2]+=rng.normal(0,.07,(P,2));pert[:,2]=np.clip(pert[:,2]+rng.normal(0,.025,P),0,4)
                starts.append(('INTERP perturbation',pert.ravel()))
        if P<=len(result['augmented']):
            previous=np.asarray(result['augmented'][P-1]['parameters']);continue
        starts.append(('legacy residual-INTERP',np.asarray(raw[P-1]['parameters']).ravel()))
        if P>=3:
            m=P//3; candidates=[r for r in baseline if r['order']==2 and r['m']==m]
            if candidates:starts.append(('Strang-informed',np.r_[strang_parameters(candidates[0]['optimized_time'],m),np.zeros(3*(P-3*m))]))
        best=None;logs=[]
        for label,start in starts:
            opt,log=optimize(start,label,P);logs.append(log)
            candidates=[(float(opt.fun),opt.x,label)]
            if label=='identity insertion':candidates.append((log['initial_infidelity'],start,label+' unchanged'))
            for candidate in candidates:
                if best is None or candidate[0]<best[0]:best=candidate
        value,par,label=best;previous=np.asarray(par).reshape(-1,3)
        result['augmented'].append(record(P,par,value,selected_start=label,trials=logs));save(path,result)
        print(f'{model_name} augmented P={P} infidelity={value:.9g} selected={label}',flush=True)
    previous=np.asarray(result['plain'][-1]['parameters']) if result['plain'] else None
    for P in range(len(result['plain'])+1,maximum+1):
        start=np.full(3,.1) if previous is None else interpolate(previous).ravel()
        opt,log=optimize(start,'plain INTERP',P);previous=opt.x.reshape(-1,3)
        result['plain'].append(record(P,opt.x,opt.fun,trials=[log]));save(path,result)
        print(f'{model_name} plain P={P} infidelity={opt.fun:.9g}',flush=True)
    for P in [3,5,7,10,15,20,30,40,50]:
        if P>maximum:continue
        for seed in range(5):
            if any(r['P']==P and r['seed']==seed for r in result['random']):continue
            random=np.random.default_rng(10000+100*P+seed)
            start=np.column_stack([random.uniform(-np.pi,np.pi,(P,2)),random.uniform(0,4/P,P)]).ravel()
            opt,log=optimize(start,'random',P)
            result['random'].append(record(P,opt.x,opt.fun,seed=seed,trials=[log]));save(path,result)
            print(f'{model_name} random P={P} seed={seed} infidelity={opt.fun:.9g}',flush=True)
    result['complete']=True;save(path,result)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['tfim','xxx'],required=True)
    parser.add_argument('--iterations',type=int,default=1000)
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args()
    if args.iterations<1:parser.error('iterations must be positive')
    run(args.model,args.iterations,args.output_dir)
