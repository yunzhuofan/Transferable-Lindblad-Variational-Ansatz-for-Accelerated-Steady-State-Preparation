"""Exact squared-Uhlmann infidelity with an adjoint circuit gradient."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
from pathlib import Path
import sys
import numpy as np
from scipy.linalg import eigh
from numba import njit
ROOT = Path(__file__).resolve().parents[2]
CODE = ROOT / 'code/physics'
sys.path.insert(0, str(CODE))
from lva_core import (Model, interpolate, unitary_h1, phase_z, dissipate,
                      diss_derivative, comm_z, h1_derivative)

@njit(cache=True)
def forward(par, rho0, kind, n, ez, h1, w, v, up, down):
    rho = rho0.copy()
    hist = np.empty((len(par), len(rho), len(rho)), np.complex128)
    for ell in range(len(par)//3):
        k = 3*ell
        rho = unitary_h1(rho, par[k], kind, n, w, v); hist[k] = rho
        rho = phase_z(rho, par[k+1], ez); hist[k+1] = rho
        rho = dissipate(rho, par[k+2], up, down); hist[k+2] = rho
    return rho, hist

@njit(cache=True)
def backward(par, hist, terminal, kind, n, ez, h1, w, v, up, down):
    g = terminal.copy()
    grad = np.zeros(len(par))
    for ell in range(len(par)//3-1, -1, -1):
        k = 3*ell
        grad[k+2] = np.vdot(g.ravel(), diss_derivative(hist[k+2], up, down).ravel()).real
        g = dissipate(g, par[k+2], up, down, True)
        grad[k+1] = np.vdot(g.ravel(), comm_z(hist[k+1], ez).ravel()).real
        g = phase_z(g, -par[k+1], ez)
        grad[k] = np.vdot(g.ravel(), h1_derivative(hist[k], kind, n, h1).ravel()).real
        g = unitary_h1(g, -par[k], kind, n, w, v)
    return grad

def loss_grad(model, parameters):
    par = np.ascontiguousarray(parameters, dtype=float).ravel()
    rho, hist = forward(par, *model._args)
    a = model.sqrt_ss @ rho @ model.sqrt_ss
    a = (a+a.conj().T)/2
    ev, vec = eigh(a, check_finite=False, driver='evd')
    # The objective is unregularized fidelity. Use the spectral pseudoinverse
    # on the support at exactly rank-deficient shallow circuit states.
    positive = np.maximum(ev, 0.)
    root_trace = np.sqrt(positive).sum()
    inverse = np.zeros_like(ev)
    support = ev > max(1e-16, ev[-1]*1e-12)
    inverse[support] = 1/np.sqrt(ev[support])
    terminal = -root_trace * model.sqrt_ss @ ((vec*inverse) @ vec.conj().T) @ model.sqrt_ss
    terminal = np.ascontiguousarray((terminal+terminal.conj().T)/2)
    grad = backward(par, hist, terminal, *model._args[1:])
    return float(1-root_trace**2), grad

if __name__ == '__main__':
    import json
    results = []
    data = ROOT/'data/source_inputs'
    for name in ['tfim', 'xxx']:
        model = Model(5, name); model.steady_state(data)
        rng = np.random.default_rng(72)
        for depth in [1, 3, 7]:
            par = np.column_stack([rng.uniform(.2, .8, (depth, 2)), rng.uniform(.3,.7,depth)]).ravel()
            value, grad = loss_grad(model, par)
            reference = model.metrics(model.state(par), trace_distance=False)['infidelity']
            # Rank-deficient shallow XXX states have sqrt(machine-epsilon)
            # noise in fidelity; h=1e-3 makes that noise negligible.
            h = 1e-3 if name == 'xxx' and depth < 7 else 1e-5
            fd = np.empty_like(grad)
            for k in range(len(par)):
                plus=par.copy(); minus=par.copy(); plus[k]+=h; minus[k]-=h
                fd[k]=(loss_grad(model,plus)[0]-loss_grad(model,minus)[0])/(2*h)
            error=float(np.max(np.abs(fd-grad)))
            row={'model':name,'P':depth,'infidelity':value,'metric_difference':abs(value-reference),'gradient_max_abs_error':error,'finite_difference_step':h}
            print(json.dumps(row), flush=True); results.append(row)
            assert abs(value-reference)<2e-7
            assert error<1e-4, row
    (ROOT/'reproduced').mkdir(exist_ok=True)
    (ROOT/'reproduced/gradient_checks.json').write_text(json.dumps(results,indent=2))
