"""Reproduce the manuscript's deterministic source INTERP chain.

Usage: OPENBLAS_NUM_THREADS=1 python run_source.py --model tfim
No target-state information enters training or parameter selection.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'code/physics'))
from lva_core import Model,interpolate

p=argparse.ArgumentParser();p.add_argument('--model',choices=['tfim','xxx'],required=True)
p.add_argument('--n',type=int,default=5);p.add_argument('--pmax',type=int,default=50)
p.add_argument('--maxiter',type=int,default=100);p.add_argument('--seed',type=int,default=0)
a=p.parse_args();root=ROOT/'reproduced/residual_seed';(root/'data').mkdir(parents=True,exist_ok=True);outpath=root/'data'/f"source_{a.model}_N{a.n}_seed{a.seed}{('_iters'+str(a.maxiter)) if a.maxiter!=100 else ''}.json"
m=Model(a.n,a.model);ss,checks=m.steady_state(root/'data');out={'model':a.model,'N_source':a.n,'maxiter_per_depth':a.maxiter,'source':'independent rerun of draft Eqs. (34)-(39)','reference_checks':checks,'records':[]}
rng=np.random.default_rng(a.seed)
old=None
if outpath.exists():
    out=json.loads(outpath.read_text());old=np.asarray(out['records'][-1]['parameters']).reshape(-1,3)
for depth in range(len(out['records'])+1,a.pmax+1):
    if old is None:
        start=np.full(3,.1) if a.seed==0 else np.r_[rng.uniform(-.2,.2,2),rng.uniform(.05,.2)]
    else:start=interpolate(old).ravel()
    t=time.perf_counter();initial=float(m.cost_grad(start)[0])
    result=minimize(m.cost_grad,start,jac=True,method='L-BFGS-B',bounds=[(-np.pi,np.pi),(-np.pi,np.pi),(0,4)]*depth,
                    options={'maxiter':a.maxiter,'gtol':1e-10,'ftol':1e-14})
    old=result.x.reshape(-1,3);rho=m.state(result.x)
    item={'P':depth,'initial_cost':initial,**m.metrics(rho),'iterations':int(result.nit),'evaluations':int(result.nfev),'converged':bool(result.success),'message':str(result.message),'seconds':time.perf_counter()-t,'parameters':old.tolist(),'dissipative_exposure':float(old[:,2].sum()),'sequential_duration_no_overhead':float(np.abs(old[:,:2]).sum()+old[:,2].sum())}
    out['records'].append(item)
    tmp=outpath.with_suffix('.tmp');tmp.write_text(json.dumps(out,indent=2));tmp.replace(outpath)
    print(json.dumps({k:v for k,v in item.items() if k!='parameters'}),flush=True)
