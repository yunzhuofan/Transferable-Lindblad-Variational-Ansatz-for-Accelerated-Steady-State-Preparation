from pathlib import Path
import sys,json,time,argparse
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'code/physics'),str(ROOT/'code/source')]
SOURCE=ROOT/'reproduced/source_extensions';SOURCE.mkdir(parents=True,exist_ok=True)
def read(path):return json.loads(Path(path).read_text())
def atomic(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def status(worker,*args,**kwargs):print(args,kwargs,flush=True)
def source(model):
    rows=read(ROOT/f'data/Figure2/training_{model}.json')['augmented']
    rows+= [r for r in read(ROOT/'data/Figure6/source_extensions.json') if r['model']==model]
    return {r['P']:r for r in rows}
def train_source(model,P,worker):
    import numpy as np
    from scipy.optimize import minimize
    
    from fidelity_objective import Model,interpolate,loss_grad,CODE
    from lva_advanced import strang_parameters
    obj=Model(5,model);_,ref=obj.steady_state(ROOT/'data/source_inputs')
    available=source(model);oldP=max(p for p in available if p<P)
    previous=np.asarray(available[oldP]['parameters'])
    interp=previous.copy()
    while len(interp)<P:interp=interpolate(interp)
    starts=[('INTERP continuation',interp.ravel()),('identity insertion',np.r_[previous.ravel(),np.zeros(3*(P-oldP))])]
    baseline=read(ROOT/f'data/source_inputs/benchmark_{model}_N5.json')['baselines']
    candidates=[r for r in baseline if r['order']==2 and r['m']==P//3]
    strang_initialization=None
    if candidates and P>=3:
        total_time=candidates[0]['optimized_time']
        strang_initialization=dict(method='existing source-only baseline time',m=P//3,total_time=total_time)
        starts.append(('Strang-informed',np.r_[strang_parameters(total_time,P//3),np.zeros(3*(P-3*(P//3)))]))
    elif P>768:
        # Beyond the old baseline table, continue its source-only time schedule.
        # This is solely an initializer; candidate selection still uses N5
        # infidelity and every L-BFGS-B call keeps the 1000-iteration cap.
        ordered=sorted([r for r in baseline if r['order']==2],key=lambda r:r['m'])
        a,b=ordered[-2:];m=P//3
        total_time=b['optimized_time']+(np.log(m)-np.log(b['m']))*(b['optimized_time']-a['optimized_time'])/(np.log(b['m'])-np.log(a['m']))
        strang_initialization=dict(method='log-time extrapolation of existing N5 baselines only',m=m,total_time=float(total_time),baseline_m=[a['m'],b['m']])
        starts.append(('Strang-informed source-time continuation',np.r_[strang_parameters(total_time,m),np.zeros(3*(P-3*m))]))
    fn=lambda x:loss_grad(obj,x)
    best=None;trials=[]
    for label,x0 in starts:
        initial=fn(x0)[0];began=time.perf_counter()
        status(worker,'source infidelity optimization',model=model,N=5,P=P,candidate=label,maxiter=1000)
        opt=minimize(fn,x0,jac=True,method='L-BFGS-B',bounds=[(-np.pi,np.pi),(-np.pi,np.pi),(0,4)]*P,
            options=dict(maxiter=1000,gtol=1e-10,ftol=1e-14,maxls=30))
        trials.append(dict(candidate=label,initial_infidelity=float(initial),final_infidelity=float(opt.fun),nit=int(opt.nit),
            nfev=int(opt.nfev),success=bool(opt.success),message=str(opt.message),seconds=time.perf_counter()-began))
        values=[(float(opt.fun),opt.x,label)]
        if label=='identity insertion':values.append((initial,x0,label+' unchanged'))
        for value in values:
            if best is None or value[0]<best[0]:best=value
    value,x,label=best
    rho=obj.state(x);metrics=obj.metrics(rho,trace_distance=False)
    assert abs(metrics['infidelity']-value)<2e-7 and abs(np.trace(rho)-1)<1e-9
    assert np.linalg.eigvalsh((rho+rho.conj().T)/2).min()>-1e-9
    row=dict(complete=True,model=model,N=5,P=P,B=3*P,objective='1 - squared Uhlmann fidelity',iterations_per_candidate=1000,
        parameters=x.reshape(-1,3).tolist(),metrics=metrics,training_infidelity=value,selected_start=label,trials=trials,
        continuation_from_depth=oldP,reference_checks=ref,strang_initialization=strang_initialization,
        extension_protocol='INTERP and exact identity insertion; Strang-informed source-only candidate, with source-baseline time continuation beyond P768. Existing trained depths unchanged.')
    atomic(SOURCE/f'{model}_P{P:03d}.json',row)
    return row

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',choices=['tfim','xxx'],required=True);p.add_argument('--P',type=int,required=True);a=p.parse_args()
    train_source(a.model,a.P,'standalone')
