"""Additional, source-classical-only cost objectives and certified circuit embeddings.

Do not use the exact source steady state in the target post-training routine.
"""
import numpy as np
from numba import njit
from lva_core import unitary_h1,phase_z,dissipate,diss_derivative,comm_z,h1_derivative

@njit(cache=True)
def _end_grad(par,rho0,kind,n,ez,h1,w,v,up,down,reference):
    rho=rho0.copy();p=len(par)//3;d=rho0.shape[0]
    hist=np.empty((3*p,d,d),np.complex128)
    for ell in range(p):
        rho=unitary_h1(rho,par[3*ell],kind,n,w,v);hist[3*ell]=rho
        rho=phase_z(rho,par[3*ell+1],ez);hist[3*ell+1]=rho
        rho=dissipate(rho,par[3*ell+2],up,down);hist[3*ell+2]=rho
    delta=rho-reference
    cost=np.vdot(delta.ravel(),delta.ravel()).real
    g=2*delta
    grad=np.zeros(len(par))
    for ell in range(p-1,-1,-1):
        k=3*ell
        grad[k+2]=np.vdot(g.ravel(),diss_derivative(hist[k+2],up,down).ravel()).real
        g=dissipate(g,par[k+2],up,down,True)
        grad[k+1]=np.vdot(g.ravel(),comm_z(hist[k+1],ez).ravel()).real
        g=phase_z(g,-par[k+1],ez)
        grad[k]=np.vdot(g.ravel(),h1_derivative(hist[k],kind,n,h1).ravel()).real
        g=unitary_h1(g,-par[k],kind,n,w,v)
    return cost,grad

def loss_grad(model,par,mode='hs'):
    par=np.ascontiguousarray(par,dtype=float).ravel()
    if mode=='residual':return model.cost_grad(par)
    if mode=='hs':
        if model.ss is None: model.steady_state()
        return _end_grad(par,*model._args,np.ascontiguousarray(model.ss))
    if mode.startswith('hybrid'):
        alpha=float(mode.rsplit(':',1)[1])
        c,g=model.cost_grad(par);v,h=loss_grad(model,par,'hs')
        return (1-alpha)*c+alpha*v,(1-alpha)*g+alpha*h
    raise ValueError(f'Unsupported classical objective {mode}')

def strang_parameters(t,m):
    """Encode symmetric A/2,B/2,D,B/2,A/2 in ordered A-B-D LVA layers.

    Reproduces one Strang step with three LVA layers and idle blocks;
    equivalence is exact at the channel level for t/m>=0.
    """
    if m<1 or t<0:raise ValueError
    h=t/m;per=np.array([[h/2,h/2,h],[0.,h/2,0.],[h/2,0.,0.]])
    return np.tile(per,(m,1)).ravel()

def block_count(par,tol=1e-9):
    """Count sequential nonzero generator blocks after exact adjacent merging.

    This is an operation count, not a duration/gate-depth cost.
    """
    p=np.asarray(par).reshape(-1,3)
    operations=[]
    for row in p:
        for i,v in enumerate(row):
            if abs(v)<=tol:continue
            if operations and operations[-1][0]==i:operations[-1]=(i,operations[-1][1]+v)
            else:operations.append((i,v))
    return sum(abs(v)>tol for _,v in operations)
