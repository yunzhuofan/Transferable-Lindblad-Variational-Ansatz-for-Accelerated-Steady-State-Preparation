"""Reference-state and local stationarity objectives in exact excitation sectors.

The local objective contains no reference steady state; the HS objective does.
Both return exact classical adjoint gradients. Physical reservoirs connect all
population sectors; no sector is individually normalized.
"""
import numpy as np
from scipy.sparse import csr_matrix

class BlockLoss:
    def __init__(self, model, mode='hs', region_length=2):
        self.m=model;self.mode=mode;self.r=region_length
        if mode not in ('hs','local','residual'): raise ValueError(mode)
        if mode=='hs' and model.ss is None: raise ValueError('Source reference is required')
        self.maps=[]
        if mode=='local':
            if not 1<=region_length<=model.n: raise ValueError('Invalid region size')
            s=1<<region_length
            for start in range(model.n-region_length+1):
                mask=(s-1)<<start;comp=((1<<model.n)-1)^mask
                rows=[];cols=[]
                for k,ids in enumerate(model.ids):
                    ia=(ids&mask)>>start;env=ids&comp
                    ii,jj=np.nonzero(env[:,None]==env[None,:])
                    rows.extend((ia[ii]+s*ia[jj]).tolist())
                    cols.extend((model.offset[k]+ii+model.ds[k]*jj).tolist())
                self.maps.append(csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(s*s,model.offset[-1])))
    def terminal(self,r):
        m=self.m
        if self.mode=='hs':
            delta=[a-b for a,b in zip(r,m.ss)]
            return m.inner(delta,delta),[2*x for x in delta]
        y=m.liouvillian(r)
        if self.mode=='residual': return m.inner(y,y),[2*x for x in m.liouvillian(y,True)]
        vec=m.pack(y);back=np.zeros_like(vec);cost=0.
        for T in self.maps:
            reduced=T@vec;cost+=np.vdot(reduced,reduced).real;back+=T.T@reduced
        nt=len(self.maps);terminal=m.unpack(back/nt)
        return cost/nt,[2*x for x in m.liouvillian(terminal,True)]
    def value(self,r): return float(self.terminal(r)[0])
    def __call__(self,par):
        m=self.m;par=np.asarray(par).reshape(-1,3);r=[x.copy() for x in m.rho0];history=[]
        for a,b,t in par:
            us=m._u(a);r=m.coherent(r,a,us=us);r1=r
            r=m.coherent(r,b,1);r2=r;r=m.dissipate(r,t)
            history.append((r1,r2,r,us))
        cost,g=self.terminal(r);grads=np.zeros_like(par)
        for ell in range(len(par)-1,-1,-1):
            a,b,t=par[ell];r1,r2,r3,us=history[ell]
            grads[ell,2]=m.inner(g,m.derivative(r3,2));g=m.dissipate(g,t,True)
            grads[ell,1]=m.inner(g,m.derivative(r2,1));g=m.coherent(g,b,1,True)
            grads[ell,0]=m.inner(g,m.derivative(r1,0));g=m.coherent(g,a,0,True,us)
        return float(cost),grads.ravel()
