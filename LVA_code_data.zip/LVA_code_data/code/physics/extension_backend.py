"""Exact GPU channel/gradient kernels used in the displayed calculations."""
import os,sys,json,tempfile,time,itertools,gc
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reproduced/gpu';OUT.mkdir(parents=True,exist_ok=True)
DATA=ROOT/'data/source_inputs'
for name in ['runtime_tmp','cuda_cache','data','figures','logs']:(OUT/name).mkdir(exist_ok=True)
os.environ.setdefault('CUPY_CACHE_DIR',str(OUT/'cuda_cache'))
import numpy as np
import cupy as cp
from scipy import sparse
from scipy.linalg import eigh
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits
from xxx_blocks import XXXBlocks
from nn_core import Problem as NNProblem
def host(x):return cp.asnumpy(x)
def inner(x,y):return float(cp.vdot(x,y).real)

class Base:
    def state(self,par):
        x=self.x0.copy()
        for j,t in enumerate(par):x=self.apply(x,j%3,t)
        return x
    def local_terminal(self,x):
        y=self.generator(x);back=cp.zeros_like(y);cost=0.
        for T in self.local_maps:
            if self.model=='tfim':
                reduced=y[T];cost+=float(cp.vdot(reduced,reduced).real)*self.local_factor
                cp.add.at(back,T,reduced*self.local_factor/len(self.local_maps))
            else:
                reduced=T@y;cost+=float(cp.vdot(reduced,reduced).real)
                back+=T.T@reduced/len(self.local_maps)
        return cost/len(self.local_maps),2*self.generator(back,adjoint=True)
    def local_value(self,x):return self.local_terminal(x)[0]
    def cost_grad(self,par):
        if self.model=='xxx':return self.host_checkpoint_cost_grad(par)
        par=np.asarray(par).reshape(-1,3);x=self.x0.copy();history=[x]
        for a,b,t in par:
            x=self.apply(x,0,a);x=self.apply(x,1,b);x=self.apply(x,2,t);history.append(x)
        cost,g=self.local_terminal(x);grad=np.zeros_like(par)
        for ell in range(len(par)-1,-1,-1):
            a,b,t=par[ell];r1=self.apply(history[ell],0,a);r2=self.apply(r1,1,b)
            grad[ell,2]=inner(g,self.generator(history[ell+1],2));g=self.apply(g,2,t,True)
            grad[ell,1]=inner(g,self.generator(r2,1));g=self.apply(g,1,b,True)
            grad[ell,0]=inner(g,self.generator(r1,0));g=self.apply(g,0,a,True)
        return cost,grad.ravel()
    def host_checkpoint_cost_grad(self,par):
        # Keep exact double-precision intermediates in host RAM, avoiding GPU
        # exhaustion and an additional expensive coherent replay per layer.
        par=np.asarray(par).reshape(-1,3);x=self.x0.copy();history=[]
        for a,b,t in par:
            r1=self.apply(x,0,a);x=self.apply(r1,1,b);x=self.apply(x,2,t)
            history.append((host(r1),host(x)))
        cost,g=self.local_terminal(x);grad=np.zeros_like(par)
        for ell in range(len(par)-1,-1,-1):
            a,b,t=par[ell];saved1,saved3=history.pop();r1=cp.asarray(saved1);r3=cp.asarray(saved3);r2=self.apply(r1,1,b)
            grad[ell,2]=inner(g,self.generator(r3,2));g=self.apply(g,2,t,True)
            grad[ell,1]=inner(g,self.generator(r2,1));g=self.apply(g,1,b,True)
            grad[ell,0]=inner(g,self.generator(r1,0));g=self.apply(g,0,a,True)
        return cost,grad.ravel()
    def trotter(self,T,m,order,reverse=False):
        h=T/m;x=self.x0.copy()
        if order==2:
            edge=2 if reverse else 0;middle=0 if reverse else 2
            x=self.apply(x,edge,h/2)
            for j in range(m):
                x=self.apply(x,1,h/2);x=self.apply(x,middle,h);x=self.apply(x,1,h/2)
                x=self.apply(x,edge,h/2 if j==m-1 else h)
            return x
        for _ in range(m):
            seq=[(0,h),(1,h),(2,h)] if order==1 else ([(2,h/2),(1,h/2),(0,h),(1,h/2),(2,h/2)] if reverse else [(0,h/2),(1,h/2),(2,h),(1,h/2),(0,h/2)])
            for k,t in seq:x=self.apply(x,k,t)
        return x
    def metrics(self,x):
        if self.model=='tfim':blocks=self.reflection_blocks(x)
        else:blocks=[host(b) for b in self.views(x)]
        root=0.;minimum=1.
        with threadpool_limits(limits=4):
            for b,q in zip(blocks,self.sqrt_ss):
                b=(b+b.conj().T)/2
                ev=eigh(q@b@q,eigvals_only=True,check_finite=False,driver='evd')
                root+=np.sqrt(np.maximum(ev,0)).sum()
        y=self.generator(x)
        return dict(infidelity=float(np.clip(1-root**2,0,1)),squared_fidelity=float(np.clip(root**2,0,1)),
                    raw_residual2=inner(y,y),trace=self.trace(x),source_hs_loss=inner(x-self.xss,x-self.xss))
    def set_reference(self,x,source):
        self.xss=cp.asarray(x);self.sqrt_ss=[]
        blocks=self.reflection_blocks(self.xss) if self.model=='tfim' else [host(b) for b in self.views(self.xss)]
        minimum=1.
        with threadpool_limits(limits=4):
            for b in blocks:
                b=(b+b.conj().T)/2;e,v=eigh(b,check_finite=False,driver='evd');minimum=min(minimum,float(e.min()))
                self.sqrt_ss.append((v*np.sqrt(np.maximum(e,0)))@v.conj().T)
        y=self.generator(self.xss);self.reference_checks=dict(source=str(source),raw_residual2=inner(y,y),trace=self.trace(self.xss),minimum_eigenvalue=minimum)
        assert minimum>-1e-9 and abs(self.trace(self.xss)-1)<1e-9,self.reference_checks

class Tfim(Base):
    def __init__(self,n,reference=True):
        self.n=n;self.model='tfim';self.r=2;self.p=NNProblem(n,backend='cuda',reference=False);self.x0=self.p.x0
        self.local_factor=2**(n-2);self.local_maps=[]
        for start in range(n-1):
            ids=[sum(a*4**(n-1-j) for a,j in zip(letters,[start,start+1])) for letters in itertools.product(range(4),repeat=2)]
            self.local_maps.append(cp.asarray(ids,dtype=cp.int64))
        if reference:
            path=ROOT/'reproduced/references'/f'tfim_N{n}.npz'
            self.set_reference(np.load(path)['state'],path)
    def apply(self,x,k,t,adjoint=False):return self.p.channels[k].apply(x,t,adjoint)
    def generator(self,x,k=3,adjoint=False):return (self.p.l if k==3 else self.p.generators[k]).apply(x,adjoint)
    def trace(self,x):return float(x[0])*np.sqrt(2**self.n)
    def reflection_blocks(self,x):return self.p.blocks(x)

class Heisenberg(Base):
    def __init__(self,n,reference=True):
        self.n=n;self.model='xxx';self.r=4;self.m=XXXBlocks(n);m=self.m
        self.ds=m.ds;self.offset=m.offset;self.dim=int(m.offset[-1]);self.ez=[cp.asarray(z) for z in m.ez]
        self.vs=[cp.asarray(v) for v in m.vs];self.ws=[cp.asarray(w) for w in m.ws]
        from cupyx.scipy.sparse import csr_matrix
        self.hs=[csr_matrix(sparse.csr_matrix(h)) for h in m.h1]
        self.maps={k:tuple(cp.asarray(v,dtype=cp.int64) for v in value) for k,value in m.maps.items()}
        self.x0=cp.asarray(m.pack(m.rho0));self.ucache={};self.local_maps=[]
        # Exact free-fermion diagonalization of the WHOLE XX+YY exponential.
        # Neighboring Givens rotations implement its basis change, with no
        # product-formula/time-step approximation and no truncation.
        single=2*(np.eye(n,k=1)+np.eye(n,k=-1));self.single_w,F=eigh(single)
        A=F.copy();self.givens=[];self.rotation_maps={}
        for col in range(n-1):
            for row in range(n-1,col,-1):
                aa,bb=A[row-1,col],A[row,col];norm=np.hypot(aa,bb)
                if norm<1e-15:continue
                c,s=aa/norm,bb/norm;u=A[row-1].copy();v=A[row].copy()
                A[row-1]=c*u+s*v;A[row]=-s*u+c*v;self.givens.append((row-1,c,s))
        assert np.linalg.norm(A-np.diag(np.diag(A)))<1e-12
        self.mode_energy=[]
        for ids in m.ids:self.mode_energy.append(cp.asarray(((ids[:,None]>>np.arange(n))&1)@self.single_w))
        for bond in range(n-1):
            row_a=[];row_b=[];col_a=[];col_b=[]
            for k,ids in enumerate(m.ids):
                d=len(ids);pos=np.flatnonzero(((ids>>bond)&1)==1);pos=pos[((ids[pos]>>(bond+1))&1)==0]
                other=np.searchsorted(ids,ids[pos]^((1<<bond)|(1<<(bond+1))))
                row_a.append((self.offset[k]+pos[:,None]+d*np.arange(d)[None,:]).ravel())
                row_b.append((self.offset[k]+other[:,None]+d*np.arange(d)[None,:]).ravel())
                col_a.append((self.offset[k]+np.arange(d)[:,None]+d*pos[None,:]).ravel())
                col_b.append((self.offset[k]+np.arange(d)[:,None]+d*other[None,:]).ravel())
            self.rotation_maps[bond]=[cp.asarray(np.concatenate(x),dtype=cp.int32) for x in [row_a,row_b,col_a,col_b]]
        self.rotate_kernel=cp.RawKernel(r'''
        #include <cupy/complex.cuh>
        extern "C" __global__ void rotate_pair(complex<double>* x,const int* ia,const int* ib,int count,double c,double s){
          int k=blockIdx.x*blockDim.x+threadIdx.x;if(k>=count)return;
          complex<double> a=x[ia[k]],b=x[ib[k]];x[ia[k]]=c*a+s*b;x[ib[k]]=-s*a+c*b;
        }''','rotate_pair')
        s=16
        for start in range(n-3):
            mask=(s-1)<<start;comp=((1<<n)-1)^mask;rows=[];cols=[]
            for k,ids in enumerate(m.ids):
                ia=(ids&mask)>>start;env=ids&comp;ii,jj=np.nonzero(env[:,None]==env[None,:])
                rows.extend((ia[ii]+s*ia[jj]).tolist());cols.extend((m.offset[k]+ii+m.ds[k]*jj).tolist())
            self.local_maps.append(csr_matrix(sparse.csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(s*s,self.dim))))
        if reference:self.load_reference()
    def views(self,x):return [x[self.offset[k]:self.offset[k+1]].reshape((d,d),order='F') for k,d in enumerate(self.ds)]
    def pack(self,rr):return cp.concatenate([r.ravel(order='F') for r in rr])
    def trace(self,x):return sum(float(cp.trace(b).real) for b in self.views(x))
    def u(self,t):
        if t not in self.ucache:
            if len(self.ucache)>=4:self.ucache.pop(next(iter(self.ucache)))
            self.ucache[t]=[(v*cp.exp(-1j*t*w))@v.conj().T for v,w in zip(self.vs,self.ws)]
        return self.ucache[t]
    def single_d(self,rr,site,up,down,t,adjoint=False,derivative=False):
        rate=up+down
        if derivative:a,b,c,e,s=-down,up,down,-up,-.5*rate
        else:
            eta=np.exp(-rate*t);p=up/rate;a,b,c,e,s=p+(1-p)*eta,p*(1-eta),(1-p)*(1-eta),1-p+p*eta,np.sqrt(eta)
        if adjoint:b,c=c,b
        out=[s*r for r in rr]
        for k,r in enumerate(rr):
            z,o,zm,om=self.maps[site,k]
            if len(z):out[k][cp.ix_(z,z)]=a*r[cp.ix_(z,z)]+b*rr[k+1][cp.ix_(zm,zm)]
            if len(o):out[k][cp.ix_(o,o)]=e*r[cp.ix_(o,o)]+c*rr[k-1][cp.ix_(om,om)]
        return out
    def apply(self,x,k,t,adjoint=False):
        if abs(t)<1e-16:return x.copy()
        rr=self.views(x)
        if k==0:
            if self.n<=10:
                us=self.u(-t if adjoint else t)
                return self.pack([u@r@u.conj().T for u,r in zip(us,rr)])
            t=-t if adjoint else t;y=x.copy()
            def rotate(bond,c,s):
                ra,rb,ca,cb=self.rotation_maps[bond]
                for ia,ib in [(ra,rb),(ca,cb)]:
                    count=len(ia)
                    self.rotate_kernel(((count+255)//256,),(256,),(y,ia,ib,np.int32(count),np.float64(c),np.float64(s)))
            for bond,c,s in self.givens:rotate(bond,c,s)
            y=self.pack([cp.exp(-1j*t*z[:,None])*r*cp.exp(1j*t*z[None,:]) for z,r in zip(self.mode_energy,self.views(y))])
            for bond,c,s in reversed(self.givens):rotate(bond,c,-s)
            return y
        if k==1:
            t=-t if adjoint else t
            return self.pack([cp.exp(-1j*t*z[:,None])*r*cp.exp(1j*t*z[None,:]) for z,r in zip(self.ez,rr)])
        for site,up,down in self.m.boundaries:rr=self.single_d(rr,site,up,down,t,adjoint)
        return self.pack(rr)
    def generator(self,x,k=3,adjoint=False):
        rr=self.views(x);sign=1j if adjoint else -1j
        if k==0:return self.pack([sign*(h@r-(h@r.T).T) for h,r in zip(self.hs,rr)])
        if k==1:return self.pack([sign*(z[:,None]-z[None,:])*r for z,r in zip(self.ez,rr)])
        if k==2:
            out=[cp.zeros_like(r) for r in rr]
            for site,u,d in self.m.boundaries:out=[a+b for a,b in zip(out,self.single_d(rr,site,u,d,0,adjoint,True))]
            return self.pack(out)
        return self.generator(x,0,adjoint)+self.generator(x,1,adjoint)+self.generator(x,2,adjoint)
    def load_reference(self):
        path=ROOT/'reproduced/references'/f'xxx_N{self.n}.npz'
        self.set_reference(np.load(path)['state'],path)

def backend(model,n):return Tfim(n) if model=='tfim' else Heisenberg(n)

