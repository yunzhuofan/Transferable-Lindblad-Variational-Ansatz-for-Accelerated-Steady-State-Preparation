"""Exact open-chain nearest-neighbor model in the full real Pauli basis."""
import os,sys,json,math,hashlib,time,itertools
from pathlib import Path
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='1'
ROOT=Path(__file__).resolve().parent

os.environ.setdefault('CUPY_CACHE_DIR',str(ROOT.parents[1]/'reproduced/cache/cupy'))
import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from scipy.sparse.linalg import LinearOperator,gmres
PAULI=[np.eye(2),np.array([[0,1],[1,0]]),np.array([[0,-1j],[1j,0]]),np.diag([1.,-1.])]
try:
    import cupy as cp
    CUDA_AVAILABLE=cp.cuda.runtime.getDeviceCount()>0
except (ImportError,OSError):cp=None;CUDA_AVAILABLE=False

def host(x):return cp.asnumpy(x) if cp is not None and isinstance(x,cp.ndarray) else np.asarray(x)
def kron(items):
    result=np.ones((1,1),complex)
    for item in items:result=np.kron(result,item)
    return result

CUDA_CODE=r'''
extern "C" __global__ void rotate(double* x,long long size,long long stride,int u,int v,double c,double s){
 long long k=(long long)blockDim.x*blockIdx.x+threadIdx.x;if(k>=size/4)return;
 long long base=(k/stride)*4*stride+k%stride;double a=x[base+u*stride],b=x[base+v*stride];
 x[base+u*stride]=c*a-s*b;x[base+v*stride]=s*a+c*b;
}
extern "C" __global__ void loss(double* x,long long size,long long stride,double r,double q,int adj){
 long long k=(long long)blockDim.x*blockIdx.x+threadIdx.x;if(k>=size/4)return;
 long long base=(k/stride)*4*stride+k%stride;double a=x[base],z=x[base+3*stride];
 if(adj){x[base]=a-(1-r)*z;x[base+3*stride]=r*z;}else{x[base+3*stride]=r*z-(1-r)*a;}
 x[base+stride]*=q;x[base+2*stride]*=q;
}
extern "C" __global__ void zz(double* x,long long size,long long stride,double c,double s){
 long long k=(long long)blockDim.x*blockIdx.x+threadIdx.x;if(k>=size/4)return;
 long long count=size/16,index=k%count;int pair=k/count;const int u[4]={4,7,1,13},v[4]={11,8,14,2};
 long long base=(index/stride)*16*stride+index%stride;double a=x[base+u[pair]*stride],b=x[base+v[pair]*stride];
 x[base+u[pair]*stride]=c*a-s*b;x[base+v[pair]*stride]=s*a+c*b;
}
extern "C" __global__ void generator(const double* x,double* y,long long size,int n,int kind,int adj,double omega,double interaction,double gamma){
 long long i=(long long)blockDim.x*blockIdx.x+threadIdx.x;if(i>=size)return;double out=0,sign=adj?-1:1;
 if(kind==0 || kind==3)for(int j=0;j<n;j++){int shift=2*j,a=(i>>shift)&3;
  if(a==2 || a==3)out+=sign*2*omega*(a==3?1:-1)*x[i^(1LL<<shift)];}
 if(kind==1 || kind==3)for(int j=0;j<n-1;j++){int shift=2*j,a=(i>>shift)&3,b=(i>>(shift+2))&3;
  bool qa=(a==1 || a==2),qb=(b==1 || b==2);if(qa!=qb){int letter=qa?a:b;out+=sign*2*interaction*(letter==2?1:-1)*x[i^(15LL<<shift)];}}
 if(kind==2 || kind==3){double diagonal=0;for(int j=0;j<n;j++){int shift=2*j,a=(i>>shift)&3;
  if(a==1 || a==2)diagonal-=gamma/2;if(a==3)diagonal-=gamma;
  if(!adj && a==3)out-=gamma*x[i^(3LL<<shift)];if(adj && a==0)out-=gamma*x[i^(3LL<<shift)];}out+=diagonal*x[i];}
 y[i]=out;
}
'''
KERNELS={}
def launch(name,count,args):
    if name not in KERNELS:KERNELS[name]=cp.RawKernel(CUDA_CODE,name)
    KERNELS[name](((count+255)//256,),(256,),args)

class Generator:
    def __init__(self,problem,kind):self.problem,self.kind=problem,kind
    def __matmul__(self,x):return self.apply(x)
    def apply(self,x,adjoint=False):
        p=self.problem
        if p.backend=='cpu':
            m=p.cpu_generators[self.kind] if self.kind<3 else p.cpu_l
            return (m.T if adjoint else m)@x
        y=cp.empty_like(x)
        launch('generator',p.dim,(x,y,np.int64(p.dim),np.int32(p.n),np.int32(self.kind),np.int32(adjoint),np.float64(p.omega),np.float64(p.interaction),np.float64(p.gamma)))
        return y

class Channel:
    def __init__(self,problem,kind):self.problem,self.kind=problem,kind;self.generator=Generator(problem,kind)
    def gate(self,t):return float(t)
    def apply(self,x,t,adjoint=False):
        p=self.problem;y=x.copy()
        if t==0:return y
        if self.kind==0:return p.rotate(y,0,2*p.omega*t*(-1 if adjoint else 1),copy=False)
        if self.kind==1:
            c,s=np.cos(2*p.interaction*t),np.sin(2*p.interaction*t)*(-1 if adjoint else 1)
            for j in range(p.n-1):
                stride=4**(p.n-2-j)
                if p.backend=='cuda':launch('zz',p.dim//4,(y,np.int64(p.dim),np.int64(stride),np.float64(c),np.float64(s)))
                else:
                    v=y.reshape(-1,16,stride)
                    for u,w in ((4,11),(7,8),(1,14),(13,2)):
                        a,b=v[:,u,:].copy(),v[:,w,:].copy();v[:,u,:]=c*a-s*b;v[:,w,:]=s*a+c*b
        else:
            r=np.exp(-p.gamma*t);q=np.sqrt(r)
            for j in range(p.n):
                stride=4**(p.n-1-j)
                if p.backend=='cuda':launch('loss',p.dim//4,(y,np.int64(p.dim),np.int64(stride),np.float64(r),np.float64(q),np.int32(adjoint)))
                else:
                    v=y.reshape(-1,4,stride)
                    if adjoint:
                        z=v[:,3,:].copy();v[:,0,:]-=(1-r)*z;v[:,3,:]=r*z
                    else:v[:,3,:]=r*v[:,3,:]-(1-r)*v[:,0,:]
                    v[:,1:3,:]*=q
        return y

class Problem:
    def __init__(self,n,omega=1.,interaction=1.,gamma=1.,backend=None,reference=True):
        self.n,self.d,self.dim=n,2**n,4**n
        self.omega,self.interaction,self.gamma=omega,interaction,gamma
        preference=backend or os.environ.get('NN_BACKEND','auto')
        self.backend='cuda' if preference=='cuda' or (preference=='auto' and n>=8 and CUDA_AVAILABLE) else 'cpu'
        if self.backend=='cuda' and not CUDA_AVAILABLE:raise RuntimeError('CUDA unavailable')
        self.xp=cp if self.backend=='cuda' else np
        if self.backend=='cpu':self.build_cpu_generators()
        initial=np.array([1.]);local=np.array([1.,0.,0.,-1.])/np.sqrt(2)
        for _ in range(n):initial=np.kron(initial,local)
        self.x0=self.xp.asarray(initial);self.channels=[Channel(self,k) for k in range(3)]
        self.generators=[ch.generator for ch in self.channels];self.l=Generator(self,3)
        self.cost_scale=1.  # Minimize raw ||L(rho)||^2 directly.
        words=np.arange(self.d);rev=np.array([int(format(i,'0{}b'.format(n))[::-1],2) for i in words])
        left=words[words<rev];self.reflection=(left,rev[left],words[words==rev])
        self.local_sites={1:((n-1)//2,),2:((n-2)//2,(n-2)//2+1)}
        if reference:
            self.prepare_reference();self.ss_blocks=self.blocks(self.xss);self.ss_sqrts=[]
            for b in self.ss_blocks:
                w,v=eigh(b)
                if w.min() < -1e-9:raise ValueError('Non-positive steady state')
                self.ss_sqrts.append((v*np.sqrt(np.maximum(w,0)))@v.conj().T)
            ss=host(self.xss)
            self.ss_local={m:self.reduced(ss,m) for m in (1,2)}
            self.ss_sites={s:self.reduced_sites(ss,s) for s in [(j,) for j in range(n)]+[(j,j+1) for j in range(n-1)]}

    def build_cpu_generators(self):
        words=np.arange(self.dim,dtype=np.int64);mats=[]
        for kind in range(3):
            rr=[];cc=[];vv=[]
            if kind==0:
                for j in range(self.n):
                    shift=2*j;a=(words>>shift)&3;mask=(a==2)|(a==3);cols=words[mask]
                    rr.append(cols^(1<<shift));cc.append(cols);vv.append(2*self.omega*np.where(a[mask]==2,1.,-1.))
            elif kind==1:
                for j in range(self.n-1):
                    shift=2*j;a=(words>>shift)&3;b=(words>>(shift+2))&3
                    qa=(a==1)|(a==2);qb=(b==1)|(b==2);mask=qa!=qb;cols=words[mask]
                    rr.append(cols^(15<<shift));cc.append(cols);vv.append(2*self.interaction*np.where(np.where(qa,a,b)[mask]==1,1.,-1.))
            else:
                diag=np.zeros(self.dim)
                for j in range(self.n):
                    shift=2*j;a=(words>>shift)&3;diag-=self.gamma*(.5*((a==1)|(a==2))+(a==3))
                    cols=words[a==0];rr.append(cols^(3<<shift));cc.append(cols);vv.append(np.full(len(cols),-self.gamma))
                rr.append(words);cc.append(words);vv.append(diag)
            mats.append(sparse.coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(self.dim,self.dim)).tocsr())
        self.cpu_generators=mats;self.cpu_l=(mats[0]+mats[1]+mats[2]).tocsr()

    def prepare_reference(self):
        directory=ROOT.parents[1]/'reproduced/references';directory.mkdir(exist_ok=True,parents=True)
        key=hashlib.sha256(Path(__file__).read_bytes()+repr((self.n,self.omega,self.interaction,self.gamma)).encode()).hexdigest()
        path=directory/'nn_obc_N{:02d}.npz'.format(self.n)
        if path.exists():
            with np.load(path) as saved:
                if str(saved['key'])==key:
                    self.xss=self.xp.asarray(saved['state']);self.reference_solver=json.loads(str(saved['solver']));return
        xp=self.xp;words=xp.arange(self.dim,dtype=xp.int64);diag=xp.zeros(self.dim)
        for j in range(self.n):
            a=(words>>(2*j))&3;diag-=self.gamma*(.5*((a==1)|(a==2))+(a==3))
        diag[0]=1.;rhs=xp.zeros(self.dim);rhs[0]=1/np.sqrt(self.d)
        def fixed(x):
            y=self.l@x;y[0]=x[0];return y
        start=time.perf_counter();residuals=[]
        if self.backend=='cuda':
            from cupyx.scipy.sparse.linalg import LinearOperator as Op,gmres as solve
            a=Op((self.dim,self.dim),matvec=fixed,dtype=np.float64);m=Op(a.shape,matvec=lambda x:x/diag,dtype=np.float64)
            state,info=solve(a,rhs,x0=self.x0,rtol=1e-12,atol=1e-14,restart=(40 if self.n<=10 else 20),maxiter=12000,M=m,callback=lambda r:residuals.append(float(r)),callback_type='pr_norm')
        else:
            a=LinearOperator((self.dim,self.dim),matvec=fixed,dtype=float);m=LinearOperator(a.shape,matvec=lambda x:x/diag,dtype=float)
            state,info=gmres(a,rhs,x0=self.x0,rtol=1e-12,atol=1e-14,restart=40,maxiter=300,M=m,callback=lambda r:residuals.append(float(r)),callback_type='pr_norm')
        residual=self.raw_cost(state)
        if info!=0 or residual>1e-18:raise RuntimeError('Steady-state solve failed: N={}, info={}, cost={}'.format(self.n,info,residual))
        self.xss=state;self.reference_solver=dict(backend=self.backend,info=int(info),iterations=len(residuals),raw_cost=residual,seconds=time.perf_counter()-start)
        temp=path.with_suffix('.writing')
        with temp.open('wb') as f:np.savez_compressed(f,state=host(state),key=key,solver=json.dumps(self.reference_solver))
        temp.replace(path)

    def raw_cost(self,x):
        residual=self.l@x;return float(self.xp.dot(residual,residual))
    def forward(self,parameters,initial=None,tape=False,skip_d=False):
        x=self.x0.copy() if initial is None else self.xp.asarray(initial).copy();saved=[]
        for j,t in enumerate(parameters):
            ch=self.channels[j%3]
            if skip_d and j%3==2:continue
            x=ch.apply(x,t)
            if tape:saved.append((ch,float(t),ch.generator@x))
        return x,saved
    def value_gradient(self,parameters):
        x,saved=self.forward(parameters,tape=True);r=self.l@x;value=self.xp.dot(r,r)
        adjoint=2*self.l.apply(r,adjoint=True);gradient=self.xp.empty(len(parameters))
        for j in range(len(saved)-1,-1,-1):
            ch,t,tangent=saved[j];gradient[j]=self.xp.dot(adjoint,tangent);adjoint=ch.apply(adjoint,t,adjoint=True)
        return float(value),host(gradient)
    def density(self,x):
        tensor=host(x).reshape([4]*self.n);transform=np.array(PAULI).reshape(4,4).T/np.sqrt(2.)
        for j in range(self.n):tensor=np.moveaxis(np.tensordot(transform,tensor,axes=(1,j)),0,j)
        return tensor.reshape([2,2]*self.n).transpose(list(range(0,2*self.n,2))+list(range(1,2*self.n,2))).reshape(self.d,self.d)
    def blocks(self,x):
        rho=self.density(x);left,right,single=self.reflection;result=[]
        for sign in (1,-1):
            u=np.concatenate([left,single]) if sign==1 else left;v=np.concatenate([right,single]) if sign==1 else right
            a=np.concatenate([np.full(len(left),1/np.sqrt(2)),np.ones(len(single))]) if sign==1 else np.full(len(left),1/np.sqrt(2))
            b=np.concatenate([np.full(len(left),1/np.sqrt(2)),np.zeros(len(single))]) if sign==1 else np.full(len(left),-1/np.sqrt(2))
            z=(a[:,None]*a[None,:]*rho[np.ix_(u,u)]+a[:,None]*b[None,:]*rho[np.ix_(u,v)]+b[:,None]*a[None,:]*rho[np.ix_(v,u)]+b[:,None]*b[None,:]*rho[np.ix_(v,v)])
            result.append((z+z.conj().T)/2)
        return result
    def reduced_sites(self,x,sites):
        coefficients=host(x);m=len(sites);result=np.zeros((2**m,2**m),complex)
        for letters in itertools.product(range(4),repeat=m):
            index=sum(a*4**(self.n-1-j) for a,j in zip(letters,sites))
            result+=coefficients[index]*np.sqrt(2**(self.n-m))*kron([PAULI[a]/np.sqrt(2) for a in letters])
        return result
    def reduced(self,x,m):return self.reduced_sites(x,self.local_sites[m])
    def trace_distance(self,x,y):return float(sum(.5*np.abs(np.linalg.eigvalsh(b)).sum() for b in self.blocks(x-y)))
    def metrics(self,x):
        bs=self.blocks(x);root_f=0.;min_eig=1.
        for b,sq in zip(bs,self.ss_sqrts):
            w,v=eigh(b);min_eig=min(min_eig,float(w.min()));sqrt_b=(v*np.sqrt(np.maximum(w,0)))@v.conj().T
            root_f+=np.linalg.svd(sq@sqrt_b,compute_uv=False).sum()
        if min_eig < -1e-9:raise ValueError('State lost positivity: '+str(min_eig))
        coefficients=host(x);purity=float(coefficients@coefficients);cost=self.raw_cost(x);fidelity=float(np.clip(root_f**2,0,1))
        result=dict(cost=cost,normalized_cost=cost/(purity*self.cost_scale),purity=purity,fidelity=fidelity,infidelity=1-fidelity,
                    trace_distance=float(sum(.5*np.abs(np.linalg.eigvalsh(b-s)).sum() for b,s in zip(bs,self.ss_blocks))),trace=float(coefficients[0]*np.sqrt(self.d)),min_eigenvalue=min_eig)
        for m in (1,2):result['local_error_'+str(m)]=float(.5*np.abs(np.linalg.eigvalsh(self.reduced(coefficients,m)-self.ss_local[m])).sum())
        rho1=self.reduced(coefficients,1);rho2=self.reduced(coefficients,2)
        for a,name in enumerate(('x','y','z'),1):
            result['magnetization_'+name]=float(np.trace(rho1@PAULI[a]).real);result['pair_'+name+name]=float(np.trace(rho2@np.kron(PAULI[a],PAULI[a])).real)
        z=[float(coefficients[3*4**(self.n-1-j)]*np.sqrt(self.d)) for j in range(self.n)];j,k=self.local_sites[2]
        result['connected_zz']=result['pair_zz']-z[j]*z[k];result['magnetization_z_mean']=float(np.mean(z))
        result['pair_zz_nn_mean']=float(np.mean([coefficients[3*(4**(self.n-1-j)+4**(self.n-2-j))]*np.sqrt(self.d) for j in range(self.n-1)]))
        for m,sites in ((1,[(j,) for j in range(self.n)]),(2,[(j,j+1) for j in range(self.n-1)])):
            result['local_error_{}_mean'.format(m)]=float(np.mean([.5*np.abs(np.linalg.eigvalsh(self.reduced_sites(coefficients,s)-self.ss_sites[s])).sum() for s in sites]))
        return result
    def reference_checks(self):
        return dict(n=self.n,dimension=self.dim,backend=self.backend,boundary='open',bonds=self.n-1,reference_residual=self.raw_cost(self.xss),
                    reference_trace=float(host(self.xss)[0]*np.sqrt(self.d)),cost_scale=self.cost_scale,gram_error=0.,
                    local_sites={str(k):list(v) for k,v in self.local_sites.items()},reference_solver=self.reference_solver,**self.metrics(self.xss))
    def rotate(self,x,axis,angle,copy=True):
        y=x.copy() if copy else x;u,v=((2,3),(3,1),(1,2))[axis];c,s=np.cos(angle),np.sin(angle)
        for j in range(self.n):
            stride=4**(self.n-1-j)
            if self.backend=='cuda':launch('rotate',self.dim//4,(y,np.int64(self.dim),np.int64(stride),np.int32(u),np.int32(v),np.float64(c),np.float64(s)))
            else:
                tensor=y.reshape(-1,4,stride);a,b=tensor[:,u,:].copy(),tensor[:,v,:].copy();tensor[:,u,:]=c*a-s*b;tensor[:,v,:]=s*a+c*b
        return y
    def rotation(self,x,axis,epsilon):return self.rotate(x,axis,epsilon)

def interpolate(parameters):
    old=np.asarray(parameters).reshape(-1,3);p=len(old);padded=np.vstack([np.zeros((1,3)),old,np.zeros((1,3))]);j=np.arange(p+1)[:,None]
    return (((j/p)*padded[:-1])+((1-j/p)*padded[1:])).ravel()
