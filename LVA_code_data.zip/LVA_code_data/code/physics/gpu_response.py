import numpy as np,itertools
import extension_backend as B
import fast_exact as FAST
cp=B.cp
class Adapter:
    def __init__(self,model,n):
        self.name,self.n=model,n
        self.backend=B.Tfim(n,reference=False) if model=='tfim' else FAST.FastHeisenberg(n,reference=False)
        self.index_cache={}
    def state(self,par):return self.backend.state(par)
    def metrics(self,state,trace_distance=False):return self.backend.metrics(state)
def residual(m, state, region):
    b = m.backend
    y = b.generator(state)
    if m.name == "tfim":
        if region not in m.index_cache:
            indices = []
            for start in range(m.n-region+1):
                indices.extend(sum(letter*4**(m.n-1-j) for letter,j in zip(letters, range(start,start+region)))
                               for letters in itertools.product(range(4), repeat=region))
            m.index_cache[region] = cp.asarray(indices, dtype=cp.int64)
        # An isometric residual representation in the orthonormal local Pauli basis.
        return cp.asnumpy(y[m.index_cache[region]])*np.sqrt(2**(m.n-region)/(m.n-region+1))
    assert region == 4
    reduced = cp.concatenate([T@y for T in b.local_maps])/np.sqrt(m.n-region+1)
    value = cp.asnumpy(reduced)
    return np.r_[value.real, value.imag]

def response(m, par, region):
    b = m.backend
    state = b.x0.copy()
    history = []
    for a,t in enumerate(par):
        state = b.apply(state, a%3, t)
        history.append(cp.asnumpy(state))
    r = residual(m, state, region)
    J = np.empty((len(r), len(par)))
    for a in range(len(par)):
        tangent = b.generator(cp.asarray(history[a]), a%3)
        for j in range(a+1, len(par)):
            tangent = b.apply(tangent, j%3, par[j])
        J[:,a] = residual(m, tangent, region)
    return r, J, state
