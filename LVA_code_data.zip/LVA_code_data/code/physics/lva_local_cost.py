"""Target-observable local stationarity loss, using no target reference state.

C_loc = (1/(N-r+1)) sum_{i=0}^{N-r} ||Tr_(complement A_i) L(rho)||_F^2.
Each local reduced derivative is reconstructible from finite local Pauli
expectations <L^dagger(P_A)> on independent prepared copies. Exact gradient
here is a classical reference implementation; hardware gradients would have
finite-shot costs.
"""
import numpy as np
from numba import njit
from lva_core import (unitary_h1,phase_z,dissipate,diss_derivative,
                      comm_z,h1_derivative,liouv_action)

@njit(cache=True)
def _project_local(y,n,r):
    d=y.shape[0];s=1<<r;nt=n-r+1
    total=0.;out=np.zeros_like(y)
    for start in range(nt):
        mask=((1<<r)-1)<<start;comp=((1<<n)-1)^mask
        red=np.zeros((s,s),dtype=np.complex128)
        for i in range(d):
            ia=(i&mask)>>start;ic=i&comp
            for j in range(d):
                if (j&comp)==ic:
                    ja=(j&mask)>>start
                    red[ia,ja]+=y[i,j]
        total+=np.vdot(red.ravel(),red.ravel()).real
        for i in range(d):
            ia=(i&mask)>>start;ic=i&comp
            for j in range(d):
                if (j&comp)==ic:
                    ja=(j&mask)>>start
                    out[i,j]+=red[ia,ja]
    return total/nt,out/nt

@njit(cache=True)
def _obj_local(par,rho0,kind,n,ez,h1,w,v,up,down,region_length):
    rho=rho0.copy();p=len(par)//3;d=rho0.shape[0]
    hist=np.empty((3*p,d,d),np.complex128)
    for ell in range(p):
        rho=unitary_h1(rho,par[3*ell],kind,n,w,v);hist[3*ell]=rho
        rho=phase_z(rho,par[3*ell+1],ez);hist[3*ell+1]=rho
        rho=dissipate(rho,par[3*ell+2],up,down);hist[3*ell+2]=rho
    residual=liouv_action(rho,kind,n,ez,h1,up,down)
    cost,terminal=_project_local(residual,n,region_length)
    g=2*liouv_action(terminal,kind,n,ez,h1,up,down,True)
    grad=np.zeros(len(par))
    for ell in range(p-1,-1,-1):
        k=3*ell
        grad[k+2]=np.vdot(g.ravel(),diss_derivative(hist[k+2],up,down).ravel()).real
        g=dissipate(g,par[k+2],up,down,True)
        grad[k+1]=np.vdot(g.ravel(),comm_z(hist[k+1],ez).ravel()).real
        g=phase_z(g,-par[k+1],ez)
        grad[k]=np.vdot(g.ravel(),h1_derivative(hist[k],kind,n,h1).ravel()).real
        g=unitary_h1(g,-par[k],kind,n,w,v)
    return cost,grad

def local_cost(model,rho,region_length=2):
    y=model.liouvillian(rho)
    c,_=_project_local(np.ascontiguousarray(y),model.n,region_length)
    return float(c)

def local_cost_grad(model,par,region_length=2):
    if not 1<=region_length<=model.n:raise ValueError('invalid support')
    return _obj_local(np.ascontiguousarray(par,dtype=float).ravel(),*model._args,region_length)
