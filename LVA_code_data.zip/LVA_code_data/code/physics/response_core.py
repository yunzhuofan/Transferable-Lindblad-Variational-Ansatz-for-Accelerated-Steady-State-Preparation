"""Exact finite-angle state and local-stationarity response; exploratory diagnostic.

All density-matrix tangents are propagated with the original CPTP blocks.
A tangent is not a density matrix and is never normalized independently.
"""
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import csr_matrix
from lva_core import h1_derivative,comm_z,diss_derivative
from block_losses import BlockLoss

def maps(m,r):
 key=f'_response_maps_{r}'
 if hasattr(m,key):return getattr(m,key)
 if hasattr(m,'ids'):out=BlockLoss(m,'local',r).maps
 else:
  out=[];d=m.d;s=1<<r;ids=np.arange(d)
  for start in range(m.n-r+1):
   mask=(s-1)<<start;env=ids&(((1<<m.n)-1)^mask);a=(ids&mask)>>start
   ii,jj=np.nonzero(env[:,None]==env[None,:])
   out.append(csr_matrix((np.ones(len(ii)),(a[ii]+s*a[jj],ii+d*jj)),shape=(s*s,d*d)))
 setattr(m,key,out);return out

def residual_vector(m,rho,r):
 y=m.liouvillian(rho)
 packed=m.pack(y) if hasattr(m,'ids') else y.ravel(order='F')
 vv=np.concatenate([t@packed for t in maps(m,r)])/np.sqrt(m.n-r+1)
 return np.r_[vv.real,vv.imag]

def copy_state(r):return [x.copy() for x in r] if isinstance(r,list) else r.copy()

def response(m,parameters,r):
 par=np.asarray(parameters,dtype=float).ravel();M=len(par)
 isblock=hasattr(m,'ids')
 us={a:m._u(par[a]) for a in range(0,M,3)} if isblock else {}
 def apply(state,a):
  which=a%3;t=par[a]
  if not isblock:return m.apply(state,which,t)
  if which==0:return m.coherent(state,t,us=us[a])
  if which==1:return m.coherent(state,t,1)
  return m.dissipate(state,t)
 def derivative(state,a):
  w=a%3
  if isblock:return m.derivative(state,w)
  if w==0:return h1_derivative(state,m.kind,m.n,m.h1)
  if w==1:return comm_z(state,m.ez)
  return diss_derivative(state,m.up,m.down)
 state=copy_state(m.rho0);hist=[]
 for a in range(M):
  state=apply(state,a);hist.append(state)
 residual=residual_vector(m,state,r);J=np.empty((len(residual),M))
 for a in range(M):
  tangent=derivative(hist[a],a)
  for b in range(a+1,M):tangent=apply(tangent,b)
  J[:,a]=residual_vector(m,tangent,r)
 return residual,J,state
