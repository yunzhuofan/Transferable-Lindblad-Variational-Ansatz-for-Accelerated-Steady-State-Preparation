"""Exact U(1)-covariant operator-space calculation for boundary-driven XXX.

The all-down initial state, allowed coherent generators and boundary channels
preserve the space of density operators block diagonal in excitation number.
All population sectors are retained, including reservoir flow between them.
Sector blocks are NOT separately normalized. Squared fidelity is computed
by summing root fidelities over the unnormalized blocks before squaring.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import scipy.sparse as sp
from scipy.linalg import eigh
from scipy.sparse.linalg import expm_multiply

class XXXBlocks:
    def __init__(self,n:int):
        self.n=n;self.d=2**n;self.name='xxx';self.kind=1
        allids=np.arange(self.d);counts=np.array([int(i).bit_count() for i in allids])
        self.ids=[allids[counts==k] for k in range(n+1)]
        self.ds=np.array([len(x) for x in self.ids]);self.offset=np.r_[0,np.cumsum(self.ds**2)]
        rank=np.empty(self.d,dtype=int)
        for ix in self.ids:rank[ix]=np.arange(len(ix))
        self.h1=[];self.ez=[];self.ws=[];self.vs=[]
        for ids in self.ids:
            h=np.zeros((len(ids),len(ids)),complex)
            z=1-2*((ids[:,None]>>np.arange(n))&1)
            for site in range(n-1):
                selected=np.flatnonzero(z[:,site]!=z[:,site+1]);mask=(1<<site)|(1<<(site+1))
                h[selected,rank[ids[selected]^mask]]+=2
            w,v=eigh(h);self.h1.append(h);self.ez.append(np.sum(z[:,:-1]*z[:,1:],axis=1))
            self.ws.append(w);self.vs.append(v)
        self.boundaries=[(n-1,1.,.2),(0,.2,1.)]
        self.maps={}
        for site,_,_ in self.boundaries:
            bit=1<<site
            for k,ids in enumerate(self.ids):
                zero=np.flatnonzero((ids&bit)==0);one=np.flatnonzero((ids&bit)>0)
                self.maps[site,k]=(zero,one,rank[ids[zero]^bit],rank[ids[one]^bit])
        self.rho0=[np.zeros((d,d),complex) for d in self.ds];self.rho0[-1][0,0]=1
        self.ss=None;self.sqrt_ss=None
    def pack(self,rhos):return np.concatenate([x.ravel(order='F') for x in rhos])
    def unpack(self,v):return [v[self.offset[k]:self.offset[k+1]].reshape((d,d),order='F').copy() for k,d in enumerate(self.ds)]
    def dense(self,rhos):
        out=np.zeros((self.d,self.d),complex)
        for ids,r in zip(self.ids,rhos):out[np.ix_(ids,ids)]=r
        return out
    def blocks(self,rho):
        return [rho[np.ix_(ix,ix)].copy() for ix in self.ids] if isinstance(rho,np.ndarray) else [r.copy() for r in rho]
    def _u(self,t):return [(v*np.exp(-1j*t*w))@v.conj().T for v,w in zip(self.vs,self.ws)]
    def coherent(self,rhos,t,which=0,adjoint=False,us=None):
        if adjoint:t=-t
        if which==0:
            if us is None:us=self._u(t)
            elif adjoint:us=[u.conj().T for u in us]
            return [u@r@u.conj().T for u,r in zip(us,rhos)]
        return [np.exp(-1j*t*z[:,None])*r*np.exp(1j*t*z[None,:]) for z,r in zip(self.ez,rhos)]
    def single_dissipation(self,rhos,site,up,down,t,adjoint=False,derivative=False):
        rate=up+down
        if derivative:a=-down;b=up;c=down;e=-up;s=-.5*rate
        else:
            q=np.exp(-t*rate);p=up/rate;s=np.sqrt(q)
            a=p+(1-p)*q;b=p*(1-q);c=(1-p)*(1-q);e=1-p+p*q
        if adjoint:b,c=c,b
        out=[s*r for r in rhos]
        for k,r in enumerate(rhos):
            z,o,zm,om=self.maps[site,k]
            if len(z):
                ix=np.ix_(z,z);out[k][ix]=a*r[ix]
                out[k][ix]+=b*rhos[k+1][np.ix_(zm,zm)]
            if len(o):
                ix=np.ix_(o,o);out[k][ix]=e*r[ix]
                out[k][ix]+=c*rhos[k-1][np.ix_(om,om)]
        return out
    def dissipate(self,rhos,t,adjoint=False):
        for site,u,d in self.boundaries:rhos=self.single_dissipation(rhos,site,u,d,t,adjoint)
        return rhos
    def derivative(self,rhos,which,adjoint=False):
        if which==0:out=[-1j*(h@r-r@h) for h,r in zip(self.h1,rhos)]
        elif which==1:out=[-1j*(z[:,None]-z[None,:])*r for z,r in zip(self.ez,rhos)]
        elif which==2:
            out=[np.zeros_like(r) for r in rhos]
            for site,u,d in self.boundaries:
                term=self.single_dissipation(rhos,site,u,d,0,adjoint,True)
                out=[x+y for x,y in zip(out,term)]
            return out
        else:raise ValueError('Invalid generator')
        return [-x for x in out] if adjoint else out
    def liouvillian(self,rhos,adjoint=False):
        xs=[self.derivative(rhos,k,adjoint) for k in range(3)]
        return [a+b+c for a,b,c in zip(*xs)]
    @staticmethod
    def inner(x,y):return sum(np.vdot(a,b).real for a,b in zip(x,y))
    def state(self,par):
        r=[x.copy() for x in self.rho0]
        for a,b,t in np.asarray(par).reshape(-1,3):
            r=self.coherent(r,a);r=self.coherent(r,b,1);r=self.dissipate(r,t)
        return r
    def cost_grad(self,par):
        par=np.asarray(par).reshape(-1,3);r=[x.copy() for x in self.rho0];history=[]
        for a,b,t in par:
            us=self._u(a);r=self.coherent(r,a,us=us);r1=r
            r=self.coherent(r,b,1);r2=r;r=self.dissipate(r,t)
            history.append((r1,r2,r,us))
        y=self.liouvillian(r);cost=self.inner(y,y);g=[2*x for x in self.liouvillian(y,True)]
        grads=np.zeros_like(par)
        for ell in range(len(par)-1,-1,-1):
            a,b,t=par[ell];r1,r2,r3,us=history[ell]
            grads[ell,2]=self.inner(g,self.derivative(r3,2));g=self.dissipate(g,t,True)
            grads[ell,1]=self.inner(g,self.derivative(r2,1));g=self.coherent(g,b,1,True)
            grads[ell,0]=self.inner(g,self.derivative(r1,0));g=self.coherent(g,a,0,True,us)
        return float(cost),grads.ravel()
    def trotter(self,t,m,order=1,reverse=False):
        dt=t/m;r=[x.copy() for x in self.rho0]
        us=self._u(dt if order==1 or reverse else dt/2)
        for _ in range(m):
            if order==1:
                r=self.coherent(r,dt,us=us);r=self.coherent(r,dt,1);r=self.dissipate(r,dt)
            elif reverse:
                r=self.dissipate(r,dt/2);r=self.coherent(r,dt/2,1);r=self.coherent(r,dt,us=us);r=self.coherent(r,dt/2,1);r=self.dissipate(r,dt/2)
            else:
                r=self.coherent(r,dt/2,us=us);r=self.coherent(r,dt/2,1);r=self.dissipate(r,dt);r=self.coherent(r,dt/2,1);r=self.coherent(r,dt/2,us=us)
        return r
    def sparse_liouvillian(self):
        blocks=[]
        for d,h,z in zip(self.ds,self.h1,self.ez):
            eye=sp.eye(d,format='csr');hh=sp.csr_matrix(h)+sp.diags(z,dtype=float)
            blocks.append(-1j*(sp.kron(eye,hh)-sp.kron(hh.T,eye)))
        L=sp.block_diag(blocks,format='csr');diagonal=np.zeros(self.offset[-1]);rows=[];cols=[];data=[]
        for site,up,down in self.boundaries:
            for k,ids in enumerate(self.ids):
                bits=((ids>>site)&1);rates=bits*up+(1-bits)*down
                diagonal[self.offset[k]:self.offset[k+1]]+=(-.5*(rates[:,None]+rates[None,:])).ravel(order='F')
                z,o,zm,om=self.maps[site,k]
                for old,new,target,rate in [(z,zm,k+1,down),(o,om,k-1,up)]:
                    if not len(old):continue
                    ii=(self.offset[target]+new[:,None]+self.ds[target]*new[None,:]).ravel()
                    jj=(self.offset[k]+old[:,None]+self.ds[k]*old[None,:]).ravel()
                    rows.append(ii);cols.append(jj);data.append(np.full(len(ii),rate))
        D=sp.csr_matrix((np.concatenate(data),(np.concatenate(rows),np.concatenate(cols))),shape=L.shape)+sp.diags(diagonal)
        return (L+D).tocsr()
    def set_reference(self,rho):
        rr=self.blocks(rho);tr=sum(np.trace(r).real for r in rr)
        rr=[(r+r.conj().T)/(2*tr) for r in rr];self.ss=rr;self.sqrt_ss=[];mineig=1
        for r in rr:
            e,v=eigh(r,check_finite=False);mineig=min(mineig,float(e.min()))
            if e.min()<-1e-10:raise ArithmeticError('Non-positive block reference')
            self.sqrt_ss.append((v*np.sqrt(np.maximum(e,0)))@v.conj().T)
        lr=self.liouvillian(rr)
        return {'trace':sum(np.trace(r).real for r in rr),'minimum_eigenvalue':mineig,'raw_residual2':self.inner(lr,lr),'purity':self.inner(rr,rr),'representation':'all number-diagonal density sectors'}
    def steady_state(self,cache_dir=None):
        path=Path(cache_dir)/f'reference_blocks_xxx_N{self.n}.npz' if cache_dir else None
        fullpath=Path(cache_dir)/f'reference_xxx_N{self.n}.npz' if cache_dir else None
        if path and path.exists():
            f=np.load(path);rr=[f[f'rho_{k}'] for k in range(self.n+1)];return rr,self.set_reference(rr)
        if fullpath and fullpath.exists():
            rr=self.blocks(np.load(fullpath)['rho']);diag=self.set_reference(rr)
        else:
            L=self.sparse_liouvillian();v=self.pack(self.rho0);dt=20.;A=dt*L;tr=A.diagonal().sum()
            for it in range(150):
                old=v;v=expm_multiply(A,v,traceA=tr);res=float(np.linalg.norm(L@v))
                if res<2e-12 and np.linalg.norm(v-old)<1e-11:break
            else:raise ArithmeticError(f'Steady state did not converge: {res}')
            rr=self.unpack(v);diag=self.set_reference(rr)
        if path:np.savez_compressed(path,**{f'rho_{k}':r for k,r in enumerate(self.ss)})
        return self.ss,diag
    def metrics(self,rhos,trace_distance=True):
        if self.ss is None:self.steady_state()
        root=0.;trd=0.
        for r,s,q in zip(rhos,self.ss,self.sqrt_ss):
            r=(r+r.conj().T)/2
            ev=eigh(q@r@q,eigvals_only=True,check_finite=False)
            root+=np.sum(np.sqrt(np.maximum(ev,0)))
            if trace_distance:trd+=.5*np.sum(np.abs(eigh(r-s,eigvals_only=True,check_finite=False)))
        lr=self.liouvillian(rhos)
        out={'squared_fidelity':min(1.,float(root**2)),'infidelity':max(0.,float(1-root**2)),'raw_residual2':self.inner(lr,lr),'trace':float(sum(np.trace(r).real for r in rhos))}
        if trace_distance:out['trace_distance']=float(trd)
        return out
