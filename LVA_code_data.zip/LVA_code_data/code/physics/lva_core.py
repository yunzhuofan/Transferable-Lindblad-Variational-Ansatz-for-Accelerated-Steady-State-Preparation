"""Exact finite-chain LVA kernels for the models in Eqs. (34)--(39).

Pauli convention: Z|0>=|0>, Z|1>=-|1>, sigma-=|1><0|.
All coherent blocks and local dissipative channels are evaluated exactly;
there is no additional bondwise splitting inside the specified blocks.
The objective is the *raw* Frobenius Lindblad residual. Reference-state
fidelity is only evaluated after training, never used to select parameters.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import numpy as np
import scipy.sparse as sp
from scipy.linalg import eigh
from scipy.sparse.linalg import spsolve, LinearOperator, gmres, expm_multiply
from numba import njit

@njit(cache=True)
def rotate_x(r, a, n):
    out=r.copy(); c=np.cos(a); s=np.sin(a)
    c2=c*c; s2=s*s; ics=1j*c*s; d=r.shape[0]
    for site in range(n):
        mask=1<<site
        for i in range(d):
            if i&mask: continue
            ii=i|mask
            for j in range(d):
                if j&mask: continue
                jj=j|mask
                r00=out[i,j];r01=out[i,jj];r10=out[ii,j];r11=out[ii,jj]
                out[i,j]=c2*r00+s2*r11+ics*(r01-r10)
                out[ii,jj]=s2*r00+c2*r11-ics*(r01-r10)
                out[i,jj]=c2*r01+s2*r10+ics*(r00-r11)
                out[ii,j]=c2*r10+s2*r01-ics*(r00-r11)
    return out

@njit(cache=True)
def phase_z(r,b,ez):
    ph=np.exp(-1j*b*ez)
    out=r.copy()
    for i in range(len(ez)):
        for j in range(len(ez)): out[i,j]*=ph[i]*ph[j].conjugate()
    return out

@njit(cache=True)
def dissipate(r,t,up,down,adjoint=False):
    out=r.copy(); d=r.shape[0]
    for site in range(len(up)):
        rate=up[site]+down[site]
        if rate==0: continue
        q=np.exp(-t*rate);sq=np.sqrt(q);p=up[site]/rate
        a=p+(1-p)*q; b=p*(1-q); c=(1-p)*(1-q); e=1-p+p*q
        if adjoint: b,c=c,b
        mask=1<<site
        for i in range(d):
            if i&mask: continue
            ii=i|mask
            for j in range(d):
                if j&mask: continue
                jj=j|mask
                r00=out[i,j];r11=out[ii,jj]
                out[i,j]=a*r00+b*r11
                out[ii,jj]=c*r00+e*r11
                out[i,jj]*=sq;out[ii,j]*=sq
    return out

@njit(cache=True)
def diss_derivative(r,up,down,adjoint=False):
    out=np.zeros_like(r); d=r.shape[0]
    for site in range(len(up)):
        u=up[site];v=down[site]; rate=u+v
        if rate==0:continue
        mask=1<<site
        for i in range(d):
            if i&mask:continue
            ii=i|mask
            for j in range(d):
                if j&mask:continue
                jj=j|mask
                r00=r[i,j];r11=r[ii,jj]
                if adjoint:
                    out[i,j]+=v*(r11-r00);out[ii,jj]+=u*(r00-r11)
                else:
                    dr=u*r11-v*r00;out[i,j]+=dr;out[ii,jj]-=dr
                out[i,jj]-=.5*rate*r[i,jj];out[ii,j]-=.5*rate*r[ii,j]
    return out

@njit(cache=True)
def comm_x(r,n):
    out=np.zeros_like(r); d=r.shape[0]
    for site in range(n):
        mask=1<<site
        for i in range(d):
            for j in range(d):out[i,j]+=-1j*(r[i^mask,j]-r[i,j^mask])
    return out

@njit(cache=True)
def comm_z(r,ez):
    out=r.copy()
    for i in range(len(ez)):
        for j in range(len(ez)):out[i,j]*=-1j*(ez[i]-ez[j])
    return out

@njit(cache=True)
def unitary_h1(r,t,kind,n,w,v):
    if kind==0:return rotate_x(r,t,n)
    u=(v*np.exp(-1j*t*w))@v.conj().T
    return u@r@u.conj().T

@njit(cache=True)
def h1_derivative(r,kind,n,h1):
    if kind==0:return comm_x(r,n)
    return -1j*(h1@r-r@h1)

@njit(cache=True)
def liouv_action(r,kind,n,ez,h1,up,down,adjoint=False):
    coherent=h1_derivative(r,kind,n,h1)+comm_z(r,ez)
    if adjoint:coherent=-coherent
    return coherent+diss_derivative(r,up,down,adjoint)

@njit(cache=True)
def circuit(par,rho0,kind,n,ez,h1,w,v,up,down):
    rho=rho0.copy()
    for ell in range(len(par)//3):
        rho=unitary_h1(rho,par[3*ell],kind,n,w,v)
        rho=phase_z(rho,par[3*ell+1],ez)
        rho=dissipate(rho,par[3*ell+2],up,down)
    return rho

@njit(cache=True)
def objective(par,rho0,kind,n,ez,h1,w,v,up,down):
    rho=rho0.copy();p=len(par)//3;d=rho0.shape[0]
    hist=np.empty((3*p,d,d),dtype=np.complex128)
    for ell in range(p):
        rho=unitary_h1(rho,par[3*ell],kind,n,w,v);hist[3*ell]=rho
        rho=phase_z(rho,par[3*ell+1],ez);hist[3*ell+1]=rho
        rho=dissipate(rho,par[3*ell+2],up,down);hist[3*ell+2]=rho
    y=liouv_action(rho,kind,n,ez,h1,up,down)
    cost=np.vdot(y.ravel(),y.ravel()).real
    g=2*liouv_action(y,kind,n,ez,h1,up,down,True)
    grad=np.zeros(len(par))
    for ell in range(p-1,-1,-1):
        k=3*ell
        grad[k+2]=np.vdot(g.ravel(),diss_derivative(hist[k+2],up,down).ravel()).real
        g=dissipate(g,par[k+2],up,down,True)
        grad[k+1]=np.vdot(g.ravel(),comm_z(hist[k+1],ez).ravel()).real
        g=phase_z(g,-par[k+1],ez)
        grad[k]=np.vdot(g.ravel(),h1_derivative(hist[k],kind,n,h1).ravel()).real
        g=unitary_h1(g,-par[k],kind,n,w,v)
    return cost,grad

@njit(cache=True)
def trotter_kernel(t,m,order,rho0,kind,n,ez,h1,w,v,up,down,reverse=False):
    dt=t/m; rho=rho0.copy()
    u=(v*np.exp(-1j*dt*w))@v.conj().T if kind==1 else np.ones((1,1),dtype=np.complex128)
    uh=(v*np.exp(-.5j*dt*w))@v.conj().T if kind==1 else np.ones((1,1),dtype=np.complex128)
    for k in range(m):
        if order==1:
            rho=u@rho@u.conj().T if kind==1 else rotate_x(rho,dt,n)
            rho=phase_z(rho,dt,ez)
            rho=dissipate(rho,dt,up,down)
        elif reverse:
            rho=dissipate(rho,dt/2,up,down)
            rho=phase_z(rho,dt/2,ez)
            rho=u@rho@u.conj().T if kind==1 else rotate_x(rho,dt,n)
            rho=phase_z(rho,dt/2,ez)
            rho=dissipate(rho,dt/2,up,down)
        else:
            rho=uh@rho@uh.conj().T if kind==1 else rotate_x(rho,dt/2,n)
            rho=phase_z(rho,dt/2,ez)
            rho=dissipate(rho,dt,up,down)
            rho=phase_z(rho,dt/2,ez)
            rho=uh@rho@uh.conj().T if kind==1 else rotate_x(rho,dt/2,n)
    return rho


def interpolate(old:np.ndarray)->np.ndarray:
    old=np.asarray(old,dtype=float).reshape(-1,3); p=len(old)
    return np.stack([np.interp(np.linspace(0,1,p+1),np.linspace(0,1,p),old[:,j]) for j in range(3)],axis=1)

class Model:
    def __init__(self,n:int,name:str='tfim'):
        if n<2 or name not in ('tfim','xxx'):raise ValueError('Use n>=2 and tfim or xxx')
        self.n=n; self.name=name; self.kind=int(name=='xxx');self.d=2**n;d=self.d
        ids=np.arange(d); bits=((ids[:,None]>>np.arange(n))&1);z=1-2*bits
        self.ez=np.ascontiguousarray(np.sum(z[:,:-1]*z[:,1:],axis=1),dtype=float)
        self.h1=np.zeros((d,d),complex)
        if self.kind==0:
            for j in range(n):self.h1[ids,ids^(1<<j)]+=1
            self.up=np.zeros(n);self.down=np.ones(n)
            self.w=np.zeros(d);self.v=np.eye(d,dtype=complex)
        else:
            for j in range(n-1):
                mask=(1<<j)|(1<<(j+1));sel=ids[bits[:,j]!=bits[:,j+1]]
                self.h1[sel,sel^mask]+=2
            self.up=np.zeros(n);self.down=np.zeros(n)
            # site n-1 is the leftmost tensor factor / left physical boundary.
            self.up[n-1]=1;self.down[n-1]=.2;self.up[0]=.2;self.down[0]=1
            self.w,vec=eigh(self.h1);self.v=np.ascontiguousarray(vec)
        self.rho0=np.zeros((d,d),complex);self.rho0[-1,-1]=1
        self.ss=None;self.sqrt_ss=None
        self._args=(self.rho0,self.kind,self.n,self.ez,self.h1,self.w,self.v,self.up,self.down)
    def apply(self,rho,which,t):
        rho=np.ascontiguousarray(rho)
        if which==0:return unitary_h1(rho,t,self.kind,self.n,self.w,self.v)
        if which==1:return phase_z(rho,t,self.ez)
        if which==2:return dissipate(rho,t,self.up,self.down)
        raise ValueError('which must be 0,1,2')
    def liouvillian(self,rho,adjoint=False):
        return liouv_action(np.ascontiguousarray(rho),self.kind,self.n,self.ez,self.h1,self.up,self.down,adjoint)
    def state(self,par):return circuit(np.asarray(par,dtype=float).reshape(-1),*self._args)
    def cost_grad(self,par):return objective(np.asarray(par,dtype=float).reshape(-1),*self._args)
    def trotter(self,t,m,order=1,reverse=False):
        if t<0 or m<1 or order not in (1,2):raise ValueError('Invalid product-formula parameters')
        return trotter_kernel(float(t),int(m),int(order),*self._args,bool(reverse))
    def sparse_liouvillian(self):
        d=self.d;ids=np.arange(d); eye=sp.eye(d,format='csr',dtype=complex)
        h=sp.csr_matrix(self.h1)+sp.diags(self.ez)
        L=-1j*(sp.kron(eye,h,format='csr')-sp.kron(h.T,eye,format='csr'))
        for site in range(self.n):
            mask=1<<site
            for rate,isup in [(self.up[site],True),(self.down[site],False)]:
                if rate==0:continue
                select=ids[(ids&mask)>0] if isup else ids[(ids&mask)==0]
                a=sp.csr_matrix((np.sqrt(rate)*np.ones(len(select)),(select^mask,select)),shape=(d,d))
                k=a.conj().T@a
                L+=sp.kron(a.conj(),a,format='csr')-.5*sp.kron(eye,k,format='csr')-.5*sp.kron(k.T,eye,format='csr')
        return L.tocsr()
    def set_reference(self,ss):
        ss=np.asarray(ss,dtype=complex);ss=(ss+ss.conj().T)/2;ss/=np.trace(ss)
        ev,vec=eigh(ss,check_finite=False)
        if ev.min()<-1e-9:raise ArithmeticError(f'Non-positive reference {ev.min()}')
        self.ss=np.ascontiguousarray(ss);self.sqrt_ss=np.ascontiguousarray((vec*np.sqrt(np.maximum(ev,0)))@vec.conj().T)
        return {'trace':float(np.trace(ss).real),'minimum_eigenvalue':float(ev.min()),
                'raw_residual2':float(np.linalg.norm(self.liouvillian(ss))**2),'purity':float(np.trace(ss@ss).real)}
    def steady_state(self,cache_dir=None):
        path=Path(cache_dir)/f'reference_{self.name}_N{self.n}.npz' if cache_dir else None
        if path and path.exists():
            ss=np.load(path)['rho'];return ss,self.set_reference(ss)
        original_L=self.sparse_liouvillian()
        d=self.d
        if self.n<=5:
            L=original_L.tolil()
            L[0,:]=0;L[0,np.arange(d)*(d+1)]=1
            rhs=np.zeros(d*d,complex);rhs[0]=1
            v=spsolve(L.tocsc(),rhs)
        else:
            # The plain Jacobi-preconditioned stationary solve is poorly
            # conditioned here. Converge the exact semigroup with an independent
            # sparse Krylov exponential instead (no product-formula bias).
            v=self.rho0.ravel(order='F').copy()
            interval=8. if self.kind==0 else 20.
            A=interval*original_L;traceA=A.diagonal().sum()
            converged=False
            for iteration in range(100):
                previous=v.copy();v=expm_multiply(A,v,traceA=traceA)
                residual=np.linalg.norm(original_L@v)
                if residual<2e-12 and np.linalg.norm(v-previous)<1e-11:
                    converged=True;break
            if not converged:raise ArithmeticError(f'Krylov steady-state convergence failed: residual={residual}')
        ss=v.reshape((d,d),order='F');diag=self.set_reference(ss)
        if diag['raw_residual2']>1e-18:raise ArithmeticError(f'Reference residual {diag}')
        if path:
            path.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(path,rho=self.ss)
        return self.ss,diag
    def metrics(self,rho,trace_distance=True):
        if self.ss is None:self.steady_state()
        rho=(rho+rho.conj().T)/2
        a=self.sqrt_ss@rho@self.sqrt_ss
        e=eigh(a,eigvals_only=True,check_finite=False)
        fidelity=float(np.square(np.sum(np.sqrt(np.maximum(e,0)))))
        out={'squared_fidelity':min(1.,fidelity),'infidelity':max(0.,1-fidelity),
             'raw_residual2':float(np.linalg.norm(self.liouvillian(rho))**2),'trace':float(np.trace(rho).real)}
        if trace_distance:out['trace_distance']=float(.5*np.sum(np.abs(eigh(rho-self.ss,eigvals_only=True,check_finite=False))))
        return out
