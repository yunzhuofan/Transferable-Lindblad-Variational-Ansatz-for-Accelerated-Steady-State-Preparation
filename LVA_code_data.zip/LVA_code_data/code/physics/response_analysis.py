import numpy as np
from scipy.optimize import LinearConstraint,minimize
from response_core import residual_vector
def projection(A, r):
    u, sv, _ = np.linalg.svd(A, full_matrices=False)
    keep = sv > max(1e-9 * sv[0], 1e-12)
    return float(np.linalg.norm(u[:, keep].T @ r) ** 2 / (r @ r)), sv

def feasible_update(m, par, r, J, V, region, residual_fn=None):
    if residual_fn is None:
        residual_fn = residual_vector
    A = J @ V
    H, b = A.T @ A, A.T @ r
    lower = np.tile([-np.pi, -np.pi, 0.0], len(par) // 3)
    upper = np.tile([np.pi, np.pi, 4.0], len(par) // 3)
    radius = 0.1
    sol = minimize(
        lambda x: (float(np.linalg.norm(r + A @ x) ** 2), 2 * (H @ x + b)),
        np.zeros(V.shape[1]), jac=True, method="SLSQP",
        constraints=[LinearConstraint(V, lower - par, upper - par),
                     dict(type="ineq", fun=lambda x: radius ** 2 - x @ x,
                          jac=lambda x: -2 * x)],
        options=dict(maxiter=200, ftol=1e-14),
    )
    direction = V @ sol.x
    constraint_violation = max(0.0, float(np.max(lower - par - direction)),
                               float(np.max(par + direction - upper)),
                               float(np.linalg.norm(direction) - radius))
    best_cost, best_alpha, best_par = float(r @ r), 0.0, par.copy()
    line_records = []
    if constraint_violation < 1e-9:
        for alpha in [1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125]:
            candidate = par + alpha * direction
            rr = residual_fn(m, m.state(candidate), region)
            cost = float(rr @ rr)
            line_records.append(dict(alpha=alpha, local_cost=cost))
            if cost < best_cost:
                best_cost, best_alpha, best_par = cost, alpha, candidate
    # References are used only after local-cost line selection has completed.
    metrics = m.metrics(m.state(best_par), trace_distance=False)
    return dict(cost_after=best_cost, fraction_removed_actual=1-best_cost/float(r@r),
                alpha=best_alpha, step_norm=float(np.linalg.norm(best_par-par)),
                infidelity_after=metrics["infidelity"],
                global_residual2_after=metrics["raw_residual2"],
                trace_after=metrics["trace"], SLSQP_success=bool(sol.success),
                SLSQP_message=str(sol.message), SLSQP_iterations=int(sol.nit),
                constraint_violation=constraint_violation,
                parameters_after=best_par.tolist(), line_search=line_records)
