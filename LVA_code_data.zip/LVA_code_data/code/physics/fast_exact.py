import extension_backend as b
np,cp=b.np,b.cp

class FastHeisenberg(b.Heisenberg):
    def __init__(self,n,reference=True):
        super().__init__(n,reference)
        self.fused_maps={}
        base=cp.arange(self.dim,dtype=cp.int32)
        for bond,(ra,rb,ca,cb) in self.rotation_maps.items():
            rp=base.copy();qp=base.copy()
            rf=cp.zeros(self.dim,dtype=cp.int8);qf=cp.zeros(self.dim,dtype=cp.int8)
            rp[ra]=rb;rp[rb]=ra;qp[ca]=cb;qp[cb]=ca
            rf[ra]=1;rf[rb]=-1;qf[ca]=1;qf[cb]=-1
            self.fused_maps[bond]=(rp,qp,rf,qf)
        self.whole_single_w,self.whole_single_v=b.eigh(2*(np.eye(n,k=1)+np.eye(n,k=-1)))
        self.control_cache={}
        self.fused=cp.RawKernel(r'''
        #include <cupy/complex.cuh>
        extern "C" __global__ void rotate_density(
          const complex<double>* x, complex<double>* y,
          const int* rp,const int* qp,const signed char* rf,const signed char* qf,
          int count,double c,double sr,double si){
          int i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=count)return;
          signed char r=rf[i],q=qf[i];
          double dr=(r==0)?1.:c,dq=(q==0)?1.:c;
          complex<double> s(sr,si),rr(0.,0.),qq(0.,0.);
          if(r==1)rr=s;else if(r==-1)rr=-conj(s);
          if(q==1)qq=conj(s);else if(q==-1)qq=-s;
          complex<double> z=dr*dq*x[i];
          if(r)z+=rr*dq*x[rp[i]];
          if(q)z+=dr*qq*x[qp[i]];
          if(r&&q)z+=rr*qq*x[qp[rp[i]]];
          y[i]=z;
        }''','rotate_density')

    def controls(self,t):
        if t in self.control_cache:return self.control_cache[t]
        F=self.whole_single_v
        A=(F*np.exp(-1j*t*self.whole_single_w))@F.T
        gates=[]
        for col in range(self.n-1):
            for row in range(self.n-1,col,-1):
                a,z=A[row-1,col],A[row,col]
                if abs(z)<1e-16:continue
                norm=np.hypot(abs(a),abs(z))
                c=abs(a)/norm
                phase=a/abs(a) if abs(a)>1e-30 else 1.+0j
                s=phase*np.conj(z)/norm
                u=A[row-1].copy();v=A[row].copy()
                A[row-1]=c*u+s*v;A[row]=-np.conj(s)*u+c*v
                gates.append((row-1,float(c),-s))
        assert np.linalg.norm(A-np.diag(np.diag(A)))<2e-12
        diag=np.diag(A)
        phases=[]
        for ids in self.m.ids:
            bits=(ids[:,None]>>np.arange(self.n))&1
            phases.append(cp.asarray(np.prod(np.where(bits,diag,1.),axis=1)))
        controls=(phases,list(reversed(gates)))
        if len(self.control_cache)>=6:self.control_cache.pop(next(iter(self.control_cache)))
        self.control_cache[t]=controls
        return controls

    def apply(self,x,k,t,adjoint=False):
        if k!=0 or abs(t)<1e-16:return super().apply(x,k,t,adjoint)
        t=-t if adjoint else t
        phases,gates=self.controls(t)
        y=self.pack([v[:,None]*r*v.conj()[None,:] for v,r in zip(phases,self.views(x))])
        for bond,c,s in gates:
            z=cp.empty_like(y)
            self.fused(((self.dim+255)//256,),(256,),
                       (y,z,*self.fused_maps[bond],np.int32(self.dim),np.float64(c),np.float64(s.real),np.float64(s.imag)))
            y=z
        return y
