from pathlib import Path
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,time,json,collections
import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp
from scipy.linalg import eig
from scipy.sparse.linalg import expm_multiply
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reproduced/modal';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'code/physics'))
from lva_core import Model
def printtime(s): print(f'[{time.strftime("%H:%M:%S")}] {s}',flush=True)

def revbits(i,n):
    return int(format(i,f'0{n}b')[::-1],2)

def reflection_projector(n):
    d=1<<n
    perm=np.array([revbits(k,n) for k in range(d)])
    seen=set(); ii=[];jj=[]; vv=[];col=0
    for j in range(d):
        for i in range(d):
            k=i+d*j
            if k in seen:continue
            v=perm[i]+d*perm[j];seen.update([k,v])
            norm=np.sqrt(1 if k==v else 2)
            for ind in sorted(set([k,v])):ii.append(ind);jj.append(col);vv.append(1/norm)
            col+=1
    return sp.csc_matrix((vv,(ii,jj)),shape=(d*d,col),dtype=complex)

def XXX_projector(n):
    d=1<<n
    inds=[i+d*j for j in range(d) for i in range(d) if i.bit_count()==j.bit_count()]
    return sp.csc_matrix((np.ones(len(inds)),(inds,np.arange(len(inds)))),shape=(d*d,len(inds)),dtype=complex)

def run_modes(L,P,rhos,name,source_type):
    if not sp.issparse(L): L=sp.csr_matrix(L)
    Lred=(P.conj().T@L@P).toarray()
    printtime(f'{name}: eigensolve {Lred.shape}')
    ev,VR=eig(Lred,check_finite=False)
    stationary=int(np.argmin(np.abs(ev)))
    non=np.array([i for i in range(len(ev)) if i!=stationary]);G=-np.real(ev[non]);si=np.argsort(G); slow=G.min()
    # unit-2norm VR vectors and solve linear coefficients, correcting stationarity through subtraction.
    X=np.column_stack([P.conj().T @ (r.ravel(order='F')) for r in rhos]);
    ss=np.load(ROOT/f'data/source_inputs/reference_{name}_N5.npz')['rho'] if name!='alltoall' else None
    if ss is None:
        vr=VR[:,stationary];
        # vector stationary in reduced basis; trace normalize and make hermitian
        rvec=P@vr
        ss=rvec.reshape((32,32),order='F');ss=(ss+ss.conj().T)/2;ss=ss/np.trace(ss)
        printtime(f'{name} stationary Frobenius norm={np.linalg.norm(ss):.10f}')
    vss=P.conj().T@(ss.ravel(order='F'))
    X=X-vss[:,None]
    try: C=sla.solve(VR,X,assume_a='gen',check_finite=False)
    except Exception as e:
        print('ERROR solve',e);raise
    # Reconstruction test in orthonormal invariant basis
    err=np.linalg.norm((VR@C)-X,axis=0)/np.maximum(np.linalg.norm(X,axis=0),1e-15)
    norminv=np.linalg.cond(VR)
    # Test right-eig eigenresidual and accessible-subspace closure
    eigres=np.linalg.norm(Lred@VR-VR*ev[None,:])/(np.linalg.norm(Lred)+1e-30)
    # leakage tests for a few columns
    residual=np.linalg.norm((L@P)-(P@Lred))/(np.linalg.norm(Lred)+1e-30)
    # diagnostic mode group thresholds; the first group contains eigenspace at slowest rate.
    cut_s=slow+max(1e-7,1e-6*max(1,slow))
    edge1,edge2= (0.8,1.5) if name=='xxx' else (1.5,2.5)
    tol=1e-7
    masks=[(G<=cut_s),(G>cut_s)&(G<edge1-tol),(G>=edge1-tol)&(G<edge2-tol),G>=edge2-tol]
    weights=np.stack([np.sqrt(np.sum(np.abs(C[non[mask],:])**2,axis=0)) for mask in masks])
    # natural exact propagation of c0, direct eigen-group weights; extra time points
    end=12 if name=='tfim' else 30;ts=np.linspace(0,end,int(end*5)+1)
    natural=np.array([np.sqrt(np.sum(np.abs(C[non[mask],0,None])**2*np.exp(-2*G[mask,None]*ts[None,:]),axis=0)) for mask in masks])
    results={'model':name,'P':source_type,'d_red':Lred.shape[0],'stationary_lambda':[float(np.real(ev[stationary])),float(np.imag(ev[stationary]))],
            'gamma_slowest':float(slow),'group_edges':[float(edge1),float(edge2)], 'group_counts':[int(k.sum()) for k in masks],
            'rate_minmax':[[float(G[k].min()),float(G[k].max())] if np.any(k) else [None,None] for k in masks],
            'reconstruction_relative_max':float(np.max(err)), 'eig_residual_relative':float(eigres), 'subspace_leakage_relative':float(residual),
            'eigenvector_condition':float(norminv), 'state_norm':np.linalg.norm(X,axis=0).tolist(), 'eigen_rates':G.tolist(),
            'B':np.arange(len(rhos)).tolist(),'weight':weights.tolist(), 'exact_t':ts.tolist(),'natural_weight':natural.tolist(),
            'invariant_basis':name=='xxx','info':'weights based on right eigenmodes normalized to unit Frobenius; numerical degeneracy caveats; stationary mode removed'}
    printtime(f'{name} results: min Γ={slow:.6g}; bins={results["group_counts"]}; condR={norminv:.3g}; spectral res={eigres:.2e}; subspace leakage={residual:.2e}; state reconstruction={err.max():.2e}')
    printtime(f'{name} weight initial {weights[:,0]} endpoint {weights[:,-1]} ||δ|| end {results["state_norm"][-1]:.6g}')
    with open(OUT/f'{name}_spectrum_modes.json','w') as f:json.dump(results,f,indent=2)
    return results

import scipy.sparse.linalg as spla
def block_trajectory(model,parameters):
    """Record the actual state after each X/XY, ZZ, and dissipative block."""
    eye=sp.eye(model.d,format='csr')
    h1=sp.csr_matrix(model.h1);hz=sp.diags(model.ez,format='csr')
    coherent1=-1j*(sp.kron(eye,h1)-sp.kron(h1.T,eye))
    coherent2=-1j*(sp.kron(eye,hz)-sp.kron(hz.T,eye))
    dissipative=model.sparse_liouvillian()-coherent1-coherent2
    state=model.rho0.ravel(order='F').copy();states=[model.rho0.copy()]
    for layer in parameters:
        for generator,duration in zip((coherent1,coherent2,dissipative),layer):
            if abs(duration)>1e-15:
                state=spla.expm_multiply(float(duration)*generator,state,
                    traceA=float(duration)*generator.diagonal().sum())
            states.append(state.reshape((model.d,model.d),order='F').copy())
    return states

if __name__=='__main__':
    for model,depth in [('tfim',7),('xxx',20)]:
        selected=json.loads((ROOT/f'data/Figure3/selected_controls_{model}.json').read_text())
        par=np.asarray(selected['record']['parameters']);m=Model(5,model)
        projector=reflection_projector(5) if model=='tfim' else XXX_projector(5)
        run_modes(m.sparse_liouvillian(),projector,block_trajectory(m,par),model,depth)
